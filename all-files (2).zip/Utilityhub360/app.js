/* Utility360 - Industrial Utility & Sustainability Management Platform */
(function(){
'use strict';

/* ============ Constants ============ */
const APP_NAME = 'Utility360';
const STORAGE_KEY = 'utility360_data_v1';
const AUTH_KEY = 'utility360_auth_v1';
const THEME_KEY = 'utility360_theme';

const MONTHS = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
const CURRENT_YEAR = new Date().getFullYear();
const YEAR_START = 2023;
const YEAR_END = Math.max(CURRENT_YEAR + 5, 2035);
const YEARS = Array.from({length: YEAR_END - YEAR_START + 1}, (_, i) => YEAR_START + i);

const ENERGY_DEPTS = ['Domestic','Weaving','Sizing','Dyeing','Washing','Bleaching','Dryer','Bando','Production Floor','Boiler','ETP & RO Plant'];
const WATER_SOURCES = ['Ground Water','Municipal Water','Tanker Water','Recycled Water','Rainwater'];
const WATER_DEPTS  = ['Domestic','Weaving','Sizing','Dyeing','Washing','Bleaching','Boiler','Generator'];
const WATER_UNITS  = ['m³','liter','gallon'];
const WASTEWATER_TYPES = ['Domestic','Dyeing','Washing','Bleaching'];
const WASTEWATER_DEPTS = ['Domestic','Dyeing','Washing','Bleaching'];
const WASTEWATER_UNITS = ['Liter','Gallon','m³'];
const RECYCLE_TYPES = ['ETP Recycled Water','RO Recovery','Reused Cooling Water','Reused Process Water'];
const GAS_DEPTS = ['Boiler','Generator','Kitchen'];
const GAS_UNITS = ['m³','MMBtu'];
const STEAM_DEPTS = ['Dyeing','Dryer','Washing','Bleaching','Sizing'];
const STEAM_SOURCES = ['Boiler-1','Boiler-2','WHR-Boiler'];
const WASTE_TYPES = ['Textile Waste','Fabric Waste','Cotton Waste','Paper','Cardboard','Plastic','Metal Scrap','Food Waste','Sludge','Chemical Containers','Hazardous Waste','Used Oil','Batteries','E-Waste','Wooden Pallets','Glass'];
const AIR_SOURCES = ['Boiler-1','Boiler-2','Boiler-3','Thermopack','Dryer','Stenter','Generator DG-1','Generator DG-2','Incinerator','Stack-1','Stack-2'];
const AIR_POLLUTANTS = ['PM (Particulate Matter)','SO₂','NOx','CO','VOC','CO₂'];
/* default regulatory limits (mg/Nm³) — editable per record */
const AIR_LIMITS = { 'PM (Particulate Matter)':150, 'SO₂':500, 'NOx':300, 'CO':150, 'VOC':50, 'CO₂':0 };
const DISPOSAL_METHODS = ['Recycled','Landfill','Incineration','Reused','Composting','Authorized Vendor'];

const ROLES = {
  administrator:         { label:'Administrator',           color:'badge-red',    perms:['view','export','manage_users','manage_settings'] },
  compliance_manager:    { label:'Compliance Manager',      color:'badge-purple', perms:['view','set_targets'] },
  sustainability_manager:{ label:'Sustainability Manager',  color:'badge-green',  perms:['view','set_targets'] },
  environment_officer:   { label:'Environment Officer',     color:'badge-teal',   perms:['view','add','delete'] },
  utility_manager:       { label:'Utility Manager',         color:'badge-amber',  perms:['view','add','delete'] },
};

const USERS_KEY = 'utility360_users_v2';
// Clear legacy v1 users (demo accounts) if present
try { localStorage.removeItem('utility360_users_v1'); } catch {}

function loadUsers(){
  try {
    const raw = localStorage.getItem(USERS_KEY);
    if (raw) return JSON.parse(raw);
  } catch {}
  const defaults = [];
  localStorage.setItem(USERS_KEY, JSON.stringify(defaults));
  return defaults;
}
function saveUsers(list){ localStorage.setItem(USERS_KEY, JSON.stringify(list)); }
let DEMO_USERS = loadUsers();

/* Emission factors (default; editable) */
const DEFAULT_EF = {
  natural_gas: 2.02,   // kg CO2 / m³
  diesel:      2.68,   // kg CO2 / litre
  lpg:         1.51,   // kg CO2 / kg
  electricity: 0.475,  // kg CO2 / kWh (Scope 2)
};

/* ============ Data store ============ */
const DB = {
  data: null,
  load(){
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) { try { this.data = JSON.parse(raw); } catch(e) { this.data = this.seed(); } }
    else this.data = this.seed();
    if (!this.data.emissionFactors) this.data.emissionFactors = {...DEFAULT_EF};
    if (!this.data.settings) this.data.settings = { companyName:'Textile Industries Ltd.', unit:'kWh', targetElectricity:250000, targetWater:8000, targetWaste:1500, targetGas:80000, targetSteam:12000, targetWastewater:6000, targetCO2:800, targetRenewable:20, targetRecycle:25, customTargets:[] };
    if (!this.data.settings.customTargets) this.data.settings.customTargets = [];
    if (typeof this.data.settings.targetGas==='undefined') this.data.settings.targetGas = 80000;
    if (typeof this.data.settings.targetSteam==='undefined') this.data.settings.targetSteam = 12000;
    if (typeof this.data.settings.targetWastewater==='undefined') this.data.settings.targetWastewater = 6000;
    if (typeof this.data.settings.targetCO2==='undefined') this.data.settings.targetCO2 = 800;
    if (typeof this.data.settings.targetRenewable==='undefined') this.data.settings.targetRenewable = 20;
    if (typeof this.data.settings.targetRecycle==='undefined') this.data.settings.targetRecycle = 25;
    if (!this.data.steam) this.data.steam = [];
    if (!this.data.air) this.data.air = [];
    if (!this.data.audit) this.data.audit = [];
    if (!this.data.backups) this.data.backups = [];
    // One-time: purge any legacy demo/fill data from previous versions.
    const PURGE_KEY = 'utility360_purge_v2';
    if (!localStorage.getItem(PURGE_KEY)) {
      ['energy','water','wastewater','recycle','gas','solar','generator','waste','production','steam','air'].forEach(k=>{
        this.data[k] = [];
      });
      localStorage.setItem(PURGE_KEY, '1');
    }
    // Backfill fuel type on legacy generator rows (if user-entered ones existed)
    if (Array.isArray(this.data.generator)) {
      this.data.generator.forEach(r => { if (!r.fuel) r.fuel = 'Diesel'; });
    }
    return this.data;
  },
  save(){ localStorage.setItem(STORAGE_KEY, JSON.stringify(this.data)); this.autoBackup(); },
  reset(){ localStorage.removeItem(STORAGE_KEY); this.data = this.seed(); this.save(); },
  autoBackup(){
    const today = new Date().toISOString().slice(0,10);
    if (!this.data.backups.some(b=>b.date===today)) {
      this.data.backups.unshift({ date:today, size:JSON.stringify(this.data).length });
      this.data.backups = this.data.backups.slice(0,30);
      localStorage.setItem(STORAGE_KEY, JSON.stringify(this.data));
    }
  },
  audit(action, module, details){
    const user = Auth.currentUser();
    this.data.audit.unshift({
      id: Date.now(),
      timestamp: new Date().toISOString(),
      user: user? user.name : 'System',
      role: user? user.role : '-',
      action, module, details
    });
    this.data.audit = this.data.audit.slice(0,500);
  },
  seed(){
    // No demo/fill data — start with empty arrays. Users enter all data themselves.
    return {
      energy: [], water: [], wastewater: [], recycle: [], gas: [],
      solar: [], generator: [], waste: [], production: [], steam: [], air: [],
      audit: [], backups: [],
      emissionFactors: {...DEFAULT_EF},
      settings: { companyName:'Textile Industries Ltd.', unit:'kWh', targetElectricity:250000, targetWater:8000, targetWaste:1500, targetGas:80000, targetSteam:12000, targetWastewater:6000, targetCO2:800, targetRenewable:20, targetRecycle:25, customTargets:[] }
    };
  }
};

/* ============ Auth ============ */
const Auth = {
  login(username, password){
    DEMO_USERS = loadUsers();
    const user = DEMO_USERS.find(u=>u.username===username && u.password===password);
    if (user) { sessionStorage.setItem(AUTH_KEY, JSON.stringify(user)); return user; }
    return null;
  },
  signup(payload){
    DEMO_USERS = loadUsers();
    if (DEMO_USERS.some(u=>u.username===payload.username)) return { error:'Username already exists' };
    if (payload.email && DEMO_USERS.some(u=>u.email && u.email.toLowerCase()===payload.email.toLowerCase())) return { error:'Email already registered' };
    if (!ROLES[payload.role]) return { error:'Invalid role' };
    const user = {
      username: payload.username, password: payload.password,
      name: payload.name || payload.username,
      email: payload.email || '',
      role: payload.role,
      company: payload.company || 'My Company'
    };
    DEMO_USERS.push(user); saveUsers(DEMO_USERS);
    return { user };
  },
  logout(){ sessionStorage.removeItem(AUTH_KEY); },
  currentUser(){ try { return JSON.parse(sessionStorage.getItem(AUTH_KEY)); } catch { return null; } },
  can(action){
    const u = this.currentUser(); if (!u) return false;
    const perms = ROLES[u.role].perms;
    // Legacy action mapping used across app: edit -> add|delete; export -> export
    if (action==='edit') return perms.includes('add') || perms.includes('delete') || perms.includes('set_targets') || perms.includes('manage_settings');
    if (action==='*') return perms.includes('manage_users') && perms.includes('manage_settings');
    return perms.includes(action);
  }
};

/* ============ Utils ============ */
const $ = (sel, root=document) => root.querySelector(sel);
const $$ = (sel, root=document) => Array.from(root.querySelectorAll(sel));
const fmt = (n, dp=0) => { if (n==null||isNaN(n)) return '0'; return Number(n).toLocaleString('en-US',{minimumFractionDigits:dp, maximumFractionDigits:dp}); };
const fmtK = (n) => n>=1e6 ? (n/1e6).toFixed(2)+'M' : n>=1e3? (n/1e3).toFixed(1)+'K' : fmt(n);
const sum = (arr, key) => arr.reduce((a,b)=>a+(+b[key]||0), 0);
const uid = () => Date.now() + Math.floor(Math.random()*1000);

function toast(msg, type='success'){
  let wrap = $('#toast-wrap');
  if (!wrap) { wrap = document.createElement('div'); wrap.id='toast-wrap'; wrap.className='toast-wrap'; document.body.appendChild(wrap); }
  const el = document.createElement('div'); el.className='toast '+type; el.textContent=msg;
  wrap.appendChild(el);
  setTimeout(()=>{ el.style.opacity='0'; setTimeout(()=>el.remove(),200); }, 2600);
}

function confirmDlg(msg){ return window.confirm(msg); }

function themeGet(){ return localStorage.getItem(THEME_KEY) || 'light'; }
function themeSet(t){ localStorage.setItem(THEME_KEY, t); document.documentElement.setAttribute('data-theme', t); }
themeSet(themeGet());

/* Chart palette */
const CHART_COLORS = ['#0ea5e9','#10b981','#f59e0b','#ef4444','#8b5cf6','#14b8a6','#ec4899','#6366f1','#84cc16','#f97316','#06b6d4','#a855f7','#22c55e','#eab308','#dc2626','#3b82f6','#d946ef','#f43f5e','#0891b2','#65a30d'];
function chartTextColor(){ return themeGet()==='dark' ? '#e2e8f0' : '#334155'; }
function chartGridColor(){ return themeGet()==='dark' ? '#263352' : '#e2e8f0'; }

/* Track chart instances for cleanup */
let CHARTS = [];
function destroyCharts(){ CHARTS.forEach(c=>{ try{c.destroy();}catch(e){} }); CHARTS = []; }

function makeChart(canvasId, config){
  const el = document.getElementById(canvasId);
  if (!el) return null;
  Chart.defaults.color = chartTextColor();
  Chart.defaults.borderColor = chartGridColor();
  Chart.defaults.font.family = "'Inter', system-ui, sans-serif";
  const c = new Chart(el, config);
  CHARTS.push(c);
  return c;
}

/* ============ App State ============ */
const State = {
  route: 'dashboard',
  yearFilter: CURRENT_YEAR,
  monthFilter: 'all',
  deptFilter: 'all',
  sidebarOpen: false,
};

/* ============ Router / Views ============ */
const NAV = [
  { group:'Overview', items:[
    { id:'dashboard', label:'Dashboard', icon:'📊' },
    { id:'kpi', label:'Environmental KPIs', icon:'🌍' },
  ]},
  { group:'Utility Modules', items:[
    { id:'energy',      label:'Energy Consumption', icon:'⚡' },
    { id:'water',       label:'Water Consumption',  icon:'💧' },
    { id:'wastewater',  label:'Wastewater',         icon:'🚿' },
    { id:'recycle',     label:'Water Recycling',    icon:'♻️' },
    { id:'gas',         label:'Natural Gas',        icon:'🔥' },
    { id:'steam',       label:'Steam Production',   icon:'♨️' },
    { id:'production',  label:'Energy Production',  icon:'🔋' },
    { id:'waste',       label:'Waste Management',   icon:'🗑️' },
    { id:'air',         label:'Air Emission',       icon:'🌬️' },
    { id:'productionData', label:'Production Data', icon:'🏭' },
    { id:'carbon',      label:'Carbon Footprint',   icon:'🌱' },
  ]},
  { group:'Insights', items:[
    { id:'compare3',  label:'3-Year Comparison', icon:'📈' },
    { id:'reports',   label:'Reports',       icon:'📑' },
    { id:'alerts',    label:'Alerts',        icon:'🚨' },
    { id:'audit',     label:'Audit Trail',   icon:'🕓' },
    { id:'settings',  label:'Settings',      icon:'⚙️' },
  ]}
];

function go(route){
  State.route = route;
  State.sidebarOpen = false;
  render();
}

/* ============ Boot ============ */
document.addEventListener('DOMContentLoaded', ()=>{
  DB.load();
  render();
});

/* ============ Render root ============ */
function render(){
  destroyCharts();
  const user = Auth.currentUser();
  const app = $('#app');
  if (!user) { app.innerHTML = renderLogin(); wireLogin(); return; }
  app.innerHTML = renderShell(user);
  wireShell();
  renderRoute();
}

/* ============ Login / Signup ============ */
let LOGIN_MODE = 'signin';

function renderLogin(){
  const isSignup = LOGIN_MODE==='signup';
  const roleOpts = Object.entries(ROLES).map(([k,v])=>`<option value="${k}">${v.label}</option>`).join('');
  return `
  <div class="login-wrap">
    <div class="login-card">
      <div class="login-logo">
        <div class="logo-badge">U</div>
        <h1>${APP_NAME}</h1>
      </div>
      <p class="login-subtitle">Industrial Utility & Sustainability Management Platform</p>
      <div class="login-tabs" style="display:flex; gap:8px; margin-bottom:14px;">
        <button type="button" class="btn ${!isSignup?'btn-primary':''}" id="tab-signin" style="flex:1;">Sign In</button>
        <button type="button" class="btn ${isSignup?'btn-primary':''}" id="tab-signup" style="flex:1;">Sign Up</button>
      </div>
      ${isSignup ? `
      <form class="login-form" id="signup-form">
        <label>Full Name</label>
        <input type="text" id="su-name" placeholder="Your full name" required/>
        <label>Company Name</label>
        <input type="text" id="su-company" placeholder="Your company name" required/>
        <label>Email</label>
        <input type="email" id="su-email" placeholder="you@company.com" required autocomplete="email"/>
        <label>Role</label>
        <select id="su-role" required>${roleOpts}</select>
        <label>Username</label>
        <input type="text" id="su-user" placeholder="Choose a username" required autocomplete="username"/>
        <label>Password</label>
        <input type="password" id="su-pass" placeholder="Choose a password" required autocomplete="new-password"/>
        <label>Retype Password</label>
        <input type="password" id="su-pass2" placeholder="Retype your password" required autocomplete="new-password"/>
        <button type="submit" class="btn-login">Create Account</button>
      </form>
      ` : `
      <form class="login-form" id="login-form">
        <label>Username</label>
        <input type="text" id="login-user" placeholder="Enter username" required autocomplete="username"/>
        <label>Password</label>
        <input type="password" id="login-pass" placeholder="Enter password" required autocomplete="current-password"/>
        <button type="submit" class="btn-login">Sign In</button>
      </form>
      <div class="login-hint">
        <small style="color:var(--text-3);">No account yet? Use <b>Sign Up</b> to create one.</small>
      </div>`}
    </div>
  </div>`;
}
function wireLogin(){
  $('#tab-signin')?.addEventListener('click', ()=>{ LOGIN_MODE='signin'; render(); });
  $('#tab-signup')?.addEventListener('click', ()=>{ LOGIN_MODE='signup'; render(); });
  $('#login-form')?.addEventListener('submit', e=>{
    e.preventDefault();
    const u = $('#login-user').value.trim();
    const p = $('#login-pass').value.trim();
    const user = Auth.login(u,p);
    if (user) {
      if (user.company) DB.data.settings.companyName = user.company;
      toast('Welcome, '+user.name);
      DB.audit('Login', 'Auth', 'User signed in'); DB.save(); render();
    } else toast('Invalid credentials', 'error');
  });
  $('#signup-form')?.addEventListener('submit', e=>{
    e.preventDefault();
    const email = $('#su-email').value.trim();
    const pass = $('#su-pass').value.trim();
    const pass2 = $('#su-pass2').value.trim();
    const emailRe = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRe.test(email)) { toast('Please enter a valid email address', 'error'); return; }
    if (pass !== pass2) { toast('Passwords do not match', 'error'); return; }
    const payload = {
      name: $('#su-name').value.trim(),
      company: $('#su-company').value.trim(),
      email: email,
      role: $('#su-role').value,
      username: $('#su-user').value.trim(),
      password: pass,
    };
    const res = Auth.signup(payload);
    if (res.error) { toast(res.error, 'error'); return; }
    const user = Auth.login(payload.username, payload.password);
    if (user) {
      if (user.company) DB.data.settings.companyName = user.company;
      DB.audit('Signup','Auth','New '+user.role+': '+user.username); DB.save();
      toast('Account created. Welcome, '+user.name);
      LOGIN_MODE='signin';
      render();
    }
  });
}

/* ============ Shell ============ */
function renderShell(user){
  const role = ROLES[user.role];
  return `
  <div class="layout">
    <aside class="sidebar ${State.sidebarOpen?'open':''}" id="sidebar">
      <div class="sidebar-header">
        <div class="logo-badge-sm">U</div>
        <h2>Utility<span>360</span></h2>
      </div>
      <nav class="nav">
        ${NAV.map(g=>`
          <div class="nav-group">${g.group}</div>
          ${g.items.map(it=>`
            <div class="nav-item ${State.route===it.id?'active':''}" data-route="${it.id}">
              <span class="ico">${it.icon}</span><span>${it.label}</span>
            </div>`).join('')}
        `).join('')}
      </nav>
    </aside>
    <div class="main">
      <header class="header">
        <div class="header-left">
          <button class="hamburger" id="hamburger" title="Menu">☰</button>
          <div class="page-title">
            ${currentPageTitle()}
            <small>${DB.data.settings.companyName}</small>
          </div>
        </div>
        <div class="header-right">
          <button class="icon-btn" id="theme-toggle" title="Toggle theme">${themeGet()==='dark'?'☀️':'🌙'}</button>
          <button class="icon-btn" id="print-btn" title="Print">🖨️</button>
          <div class="dropdown">
            <div class="user-chip" id="user-chip">
              <div class="avatar">${user.name.split(' ').map(x=>x[0]).slice(0,2).join('')}</div>
              <div>
                <div>${user.name}</div>
                <small>${role.label}</small>
              </div>
            </div>
            <div class="dropdown-menu" id="user-menu">
              <div class="dropdown-item" data-action="profile">👤 ${user.name}</div>
              <div class="dropdown-item"><span class="badge ${role.color}">${role.label}</span></div>
              <div class="dropdown-divider"></div>
              <div class="dropdown-item" data-action="backup">💾 Backup Now</div>
              <div class="dropdown-item" data-action="restore">📂 Restore Data</div>
              <div class="dropdown-divider"></div>
              <div class="dropdown-item" data-action="logout">🚪 Sign Out</div>
            </div>
          </div>
        </div>
      </header>
      <main class="content" id="content"></main>
    </div>
  </div>
  <div class="modal-backdrop" id="modal-backdrop"><div class="modal" id="modal"></div></div>
  <div class="toast-wrap" id="toast-wrap"></div>`;
}

function currentPageTitle(){
  for (const g of NAV) for (const it of g.items) if (it.id===State.route) return it.label;
  return 'Dashboard';
}

function wireShell(){
  $$('.nav-item').forEach(el=>el.addEventListener('click', ()=>go(el.dataset.route)));
  $('#hamburger').addEventListener('click', ()=>{ State.sidebarOpen=!State.sidebarOpen; $('#sidebar').classList.toggle('open', State.sidebarOpen); });
  $('#theme-toggle').addEventListener('click', ()=>{
    themeSet(themeGet()==='dark'?'light':'dark');
    render();
  });
  $('#print-btn').addEventListener('click', ()=>window.print());
  const chip = $('#user-chip'), menu = $('#user-menu');
  chip.addEventListener('click', e=>{ e.stopPropagation(); menu.classList.toggle('open'); });
  document.addEventListener('click', ()=>menu.classList.remove('open'));
  $$('.dropdown-item[data-action]').forEach(it=>{
    it.addEventListener('click', ()=>{
      const a = it.dataset.action;
      if (a==='logout'){ DB.audit('Logout','Auth','User signed out'); DB.save(); Auth.logout(); render(); }
      else if (a==='backup'){ doBackup(); }
      else if (a==='restore'){ doRestore(); }
    });
  });
}

/* ============ Backup/Restore ============ */
function doBackup(){
  const blob = new Blob([JSON.stringify(DB.data,null,2)], {type:'application/json'});
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a'); a.href=url; a.download='utility360-backup-'+new Date().toISOString().slice(0,10)+'.json';
  a.click(); URL.revokeObjectURL(url);
  DB.audit('Backup','System','Manual backup exported'); DB.save();
  toast('Backup downloaded');
}
function doRestore(){
  const inp = document.createElement('input'); inp.type='file'; inp.accept='.json';
  inp.onchange = e=>{
    const file = e.target.files[0]; if (!file) return;
    const rd = new FileReader();
    rd.onload = ev => {
      try {
        const obj = JSON.parse(ev.target.result);
        DB.data = obj; DB.save(); DB.audit('Restore','System','Data restored from backup'); DB.save();
        toast('Data restored'); render();
      } catch { toast('Invalid file','error'); }
    };
    rd.readAsText(file);
  };
  inp.click();
}

/* ============ Route dispatch ============ */
function renderRoute(){
  const el = $('#content');
  const map = {
    dashboard:       renderDashboard,
    kpi:             renderKPIView,
    energy:          () => renderModuleEnergy(el),
    water:           () => renderModuleWater(el),
    wastewater:      () => renderModuleWastewater(el),
    recycle:         () => renderModuleRecycle(el),
    gas:             () => renderModuleGas(el),
    steam:           () => renderModuleSteam(el),
    production:      () => renderModuleProduction(el),
    waste:           () => renderModuleWaste(el),
    air:             () => renderModuleAir(el),
    productionData:  () => renderModuleProductionData(el),
    carbon:          renderCarbon,
    compare3:        renderCompare3,
    reports:         renderReports,
    alerts:          renderAlerts,
    audit:           renderAudit,
    settings:        renderSettings,
  };
  const fn = map[State.route] || renderDashboard;
  const html = fn(el);
  if (typeof html === 'string') el.innerHTML = html;
  // Post-render hooks
  setTimeout(()=>{ postRender(); }, 10);
}
function postRender(){
  const fn = window['_post_'+State.route];
  if (fn) fn();
}

/* ============ Aggregations ============ */
function yearData(arr, year){ return arr.filter(x=>x.year===year); }
function filtered(arr){
  const y = State.yearFilter;
  return arr.filter(x=> (State.yearFilter==='all' || x.year===y) && (State.monthFilter==='all' || x.month==+State.monthFilter));
}

function totals(year=State.yearFilter){
  const y = year;
  const eArr = yearData(DB.data.energy, y);
  const wArr = yearData(DB.data.water, y);
  const wwArr = yearData(DB.data.wastewater, y);
  const rArr = yearData(DB.data.recycle, y);
  const gArr = yearData(DB.data.gas, y);
  const sArr = yearData(DB.data.solar, y);
  const genArr = yearData(DB.data.generator, y);
  const wsArr = yearData(DB.data.waste, y);
  const pArr = yearData(DB.data.production, y);

  const electricity = sum(eArr,'consumption');
  const water = sum(wArr,'consumption');
  const groundW = sum(wArr.filter(x=>x.source==='Ground Water'),'consumption');
  const muniW = sum(wArr.filter(x=>x.source==='Municipal Water'),'consumption');
  const wastewater = sum(wwArr,'effluent');
  const recycled = sum(rArr,'quantity');
  const recycleRate = water>0 ? (recycled/(water+recycled)*100) : 0;
  const gas = sum(gArr,'consumption');
  const steamArr = yearData(DB.data.steam||[], y);
  const steamGen = sum(steamArr,'generation');
  const steamCons = sum(steamArr,'consumption');
  const steamEff = steamArr.length ? (sum(steamArr,'efficiency')/steamArr.length) : 0;
  const diesel = sum(genArr.filter(x=>(x.fuel||'Diesel')==='Diesel'),'diesel');
  const genNaturalGas = sum(genArr.filter(x=>x.fuel==='Natural Gas'),'diesel');
  const genEnergy = sum(genArr,'energy');
  const solar = sum(sArr,'monthly');
  const totalWaste = sum(wsArr,'quantity');
  const recycledWaste = sum(wsArr.filter(x=>x.disposal==='Recycled'),'quantity');
  const hazardousWaste = sum(wsArr.filter(x=>x.hazardous),'quantity');
  const totalProduction = sum(pArr,'quantity');
  const totalPieces = sum(pArr,'pieces');
  // Air emissions
  const airArr = yearData(DB.data.air||[], y);
  const airTotal = sum(airArr,'mass');
  const airPM   = sum(airArr.filter(x=>x.pollutant==='PM (Particulate Matter)'),'mass');
  const airSO2  = sum(airArr.filter(x=>x.pollutant==='SO₂'),'mass');
  const airNOx  = sum(airArr.filter(x=>x.pollutant==='NOx'),'mass');
  const airCO   = sum(airArr.filter(x=>x.pollutant==='CO'),'mass');
  const airVOC  = sum(airArr.filter(x=>x.pollutant==='VOC'),'mass');
  const airCO2  = sum(airArr.filter(x=>x.pollutant==='CO₂'),'mass');
  const airExceedances = airArr.filter(x=> x.limit>0 && +x.concentration > +x.limit).length;
  const totalEnergy = electricity + solar + genEnergy;
  const renewable = solar;
  const renewablePct = totalEnergy>0 ? (renewable/totalEnergy)*100 : 0;
  const ef = DB.data.emissionFactors;
  const scope1 = gas*ef.natural_gas + diesel*ef.diesel + genNaturalGas*ef.natural_gas;
  const scope2 = electricity*ef.electricity;
  const carbon = scope1 + scope2;
  const energyIntensity = totalProduction>0 ? electricity/totalProduction : 0;
  const waterIntensity = totalProduction>0 ? water/totalProduction : 0;
  const wasteIntensity = totalProduction>0 ? totalWaste/totalProduction : 0;
  const gasIntensity = totalProduction>0 ? gas/totalProduction : 0;
  const wwIntensity = totalProduction>0 ? wastewater/totalProduction : 0;
  const co2PerKg = totalProduction>0 ? carbon/totalProduction : 0;
  const co2PerPc = totalPieces>0 ? carbon/totalPieces : 0;

  return { electricity, water, groundW, muniW, wastewater, recycled, recycleRate,
    gas, steamGen, steamCons, steamEff, diesel, genNaturalGas, genEnergy, solar, totalWaste, recycledWaste, hazardousWaste,
    totalProduction, totalPieces, totalEnergy, renewable, renewablePct,
    scope1, scope2, carbon, energyIntensity, waterIntensity, wasteIntensity, gasIntensity, wwIntensity,
    co2PerKg, co2PerPc,
    airTotal, airPM, airSO2, airNOx, airCO, airVOC, airCO2, airExceedances };
}

function monthlySeries(arr, key, year){
  const out = new Array(12).fill(0);
  arr.filter(x=>x.year===year).forEach(x=>{ out[x.month-1] += (+x[key]||0); });
  return out;
}

/* ============ Dashboard ============ */
function renderDashboard(){
  const t = totals();
  const yr = State.yearFilter;
  return `
  <div class="toolbar no-print">
    <select id="yearSel">${YEARS.map(y=>`<option ${y===yr?'selected':''}>${y}</option>`).join('')}</select>
    <div style="flex:1"></div>
    <span style="color:var(--text-3); font-size:12px;">Fiscal Year ${yr}</span>
  </div>

  <div class="kpi-grid">
    ${kpi('Total Electricity', fmt(t.electricity)+' kWh', '⚡', 'blue', `Cost: ৳${fmtK(t.electricity*12.5)}`)}
    ${kpi('Total Water', fmt(t.water)+' m³', '💧', 'teal', `Intensity: ${t.waterIntensity.toFixed(3)} m³/kg`)}
    ${kpi('Ground Water', fmt(t.groundW)+' m³', '🌊', 'blue', `${((t.groundW/(t.water||1))*100).toFixed(1)}% of total`)}
    ${kpi('Municipal Water', fmt(t.muniW)+' m³', '🚰', 'teal', `${((t.muniW/(t.water||1))*100).toFixed(1)}% of total`)}
    ${kpi('Wastewater', fmt(t.wastewater)+' m³', '🚿', 'amber', `Intensity: ${t.wwIntensity.toFixed(3)}`)}
    ${kpi('Water Recycled', fmt(t.recycled)+' m³', '♻️', 'green', `Rate: ${t.recycleRate.toFixed(1)}%`)}
    ${kpi('Recycling Rate', t.recycleRate.toFixed(1)+'%', '📈', 'green')}
    ${kpi('Natural Gas', fmt(t.gas)+' m³', '🔥', 'red', `Intensity: ${t.gasIntensity.toFixed(3)}`)}
    ${kpi('Steam Generated', fmt(t.steamGen)+' kg', '♨️', 'red', `Eff: ${t.steamEff.toFixed(1)}%`)}
    ${kpi('Steam Consumed', fmt(t.steamCons)+' kg', '🌡️', 'amber')}
    ${kpi('Diesel Consumed', fmt(t.diesel)+' L', '⛽', 'amber')}
    ${kpi('Generator Energy', fmt(t.genEnergy)+' kWh', '🔌', 'amber')}
    ${kpi('Solar Energy', fmt(t.solar)+' kWh', '☀️', 'green', 'Renewable')}
    ${kpi('Renewable %', t.renewablePct.toFixed(1)+'%', '🌱', 'green')}
    ${kpi('Non-Renewable %', (100-t.renewablePct).toFixed(1)+'%', '⚙️', 'red')}
    ${kpi('Total Waste', fmt(t.totalWaste)+' kg', '🗑️', 'purple')}
    ${kpi('Recycled Waste', fmt(t.recycledWaste)+' kg', '♻️', 'green', `${((t.recycledWaste/(t.totalWaste||1))*100).toFixed(1)}% diversion`)}
    ${kpi('Hazardous Waste', fmt(t.hazardousWaste)+' kg', '☣️', 'red')}
    ${kpi('Scope 1 CO₂', fmt(t.scope1/1000,1)+' tCO₂', '🏭', 'red')}
    ${kpi('Scope 2 CO₂', fmt(t.scope2/1000,1)+' tCO₂', '⚡', 'amber')}
    ${kpi('Energy Intensity', t.energyIntensity.toFixed(3)+' kWh/kg', '📊', 'indigo')}
    ${kpi('Water Intensity', t.waterIntensity.toFixed(3)+' m³/kg', '📊', 'teal')}
    ${kpi('Air Emissions (Total)', fmt(t.airTotal,2)+' kg', '🌬️', 'purple', `Records: ${(DB.data.air||[]).filter(r=>r.year===yr).length}`)}
    ${kpi('PM Emitted', fmt(t.airPM,2)+' kg', '💨', 'amber')}
    ${kpi('SO₂ Emitted', fmt(t.airSO2,2)+' kg', '🧪', 'red')}
    ${kpi('NOx Emitted', fmt(t.airNOx,2)+' kg', '☁️', 'red')}
    ${kpi('Emission Exceedances', t.airExceedances+'', t.airExceedances>0?'⚠️':'✅', t.airExceedances>0?'red':'green')}
  </div>

  <div class="charts-grid">
    <div class="card"><h3>Monthly Trend — Electricity, Water & Gas</h3><div class="chart-box"><canvas id="ch-trend"></canvas></div></div>
    <div class="card"><h3>Department Energy Comparison</h3><div class="chart-box"><canvas id="ch-dept"></canvas></div></div>
    <div class="card"><h3>Utility Cost Analysis</h3><div class="chart-box"><canvas id="ch-cost"></canvas></div></div>
    <div class="card"><h3>Three-Year Electricity Comparison</h3><div class="chart-box"><canvas id="ch-3yr"></canvas></div></div>
    <div class="card"><h3>Target vs Actual (Electricity)</h3><div class="chart-box"><canvas id="ch-target"></canvas></div></div>
    <div class="card"><h3>Environmental Performance Score</h3><div class="chart-box"><canvas id="ch-score"></canvas></div></div>
    <div class="card"><h3>Water Source Mix</h3><div class="chart-box"><canvas id="ch-water-src"></canvas></div></div>
    <div class="card"><h3>Renewable vs Non-Renewable Energy</h3><div class="chart-box"><canvas id="ch-renew"></canvas></div></div>
    <div class="card"><h3>Air Emissions by Pollutant</h3><div class="chart-box"><canvas id="ch-air-pol"></canvas></div></div>
    <div class="card"><h3>Air Emissions — Monthly Trend</h3><div class="chart-box"><canvas id="ch-air-trend"></canvas></div></div>
  </div>`;
}

function kpi(label, val, ico, color='blue', sub=''){
  return `<div class="kpi k-${color}">
    <div class="kpi-icon">${ico}</div>
    <div class="kpi-label">${label}</div>
    <div class="kpi-value">${val}</div>
    ${sub?`<div class="kpi-sub">${sub}</div>`:''}
  </div>`;
}

window._post_dashboard = function(){
  const y = State.yearFilter;
  $('#yearSel')?.addEventListener('change', e=>{ State.yearFilter=+e.target.value; renderRoute(); });

  // Trend
  const elec = monthlySeries(DB.data.energy,'consumption',y);
  const wat = monthlySeries(DB.data.water,'consumption',y);
  const gas = monthlySeries(DB.data.gas,'consumption',y);
  makeChart('ch-trend', {
    type:'line',
    data:{ labels:MONTHS, datasets:[
      { label:'Electricity (kWh)', data:elec, borderColor:'#0ea5e9', backgroundColor:'rgba(14,165,233,.1)', tension:.35, fill:true, yAxisID:'y' },
      { label:'Water (m³)', data:wat, borderColor:'#14b8a6', backgroundColor:'rgba(20,184,166,.1)', tension:.35, fill:true, yAxisID:'y1' },
      { label:'Gas (m³)', data:gas, borderColor:'#ef4444', backgroundColor:'rgba(239,68,68,.1)', tension:.35, fill:true, yAxisID:'y1' },
    ]},
    options:{ responsive:true, maintainAspectRatio:false,
      scales:{ y:{position:'left', title:{display:true,text:'kWh'}}, y1:{position:'right', title:{display:true,text:'m³'}, grid:{drawOnChartArea:false}} }
    }
  });

  // Dept comparison
  const deptTotals = {};
  yearData(DB.data.energy,y).forEach(r=>{ deptTotals[r.department] = (deptTotals[r.department]||0) + r.consumption; });
  const dLabels = Object.keys(deptTotals).sort((a,b)=>deptTotals[b]-deptTotals[a]);
  makeChart('ch-dept', {
    type:'bar',
    data:{ labels:dLabels, datasets:[{ label:'kWh', data:dLabels.map(d=>deptTotals[d]), backgroundColor:CHART_COLORS }] },
    options:{ indexAxis:'y', responsive:true, maintainAspectRatio:false, plugins:{legend:{display:false}} }
  });

  // Cost
  const costElec = sum(yearData(DB.data.energy,y),'total');
  const costWater = sum(yearData(DB.data.water,y),'total');
  const costGas = sum(yearData(DB.data.gas,y),'total');
  const costDiesel = sum(yearData(DB.data.generator,y),'diesel')*110;
  makeChart('ch-cost', {
    type:'doughnut',
    data:{ labels:['Electricity','Water','Natural Gas','Diesel'],
      datasets:[{ data:[costElec,costWater,costGas,costDiesel], backgroundColor:['#0ea5e9','#14b8a6','#ef4444','#f59e0b'] }] },
    options:{ responsive:true, maintainAspectRatio:false }
  });

  // 3-year
  const y1 = monthlySeries(DB.data.energy,'consumption',CURRENT_YEAR-2);
  const y2 = monthlySeries(DB.data.energy,'consumption',CURRENT_YEAR-1);
  const y3 = monthlySeries(DB.data.energy,'consumption',CURRENT_YEAR);
  makeChart('ch-3yr', {
    type:'bar',
    data:{ labels:MONTHS, datasets:[
      { label:CURRENT_YEAR-2, data:y1, backgroundColor:'#94a3b8' },
      { label:CURRENT_YEAR-1, data:y2, backgroundColor:'#0ea5e9' },
      { label:CURRENT_YEAR,   data:y3, backgroundColor:'#10b981' },
    ]},
    options:{ responsive:true, maintainAspectRatio:false }
  });

  // Target vs actual
  const target = DB.data.settings.targetElectricity;
  makeChart('ch-target', {
    type:'bar',
    data:{ labels:MONTHS, datasets:[
      { label:'Actual', data:elec, backgroundColor:'#0ea5e9' },
      { label:'Target', data:MONTHS.map(()=>target), type:'line', borderColor:'#ef4444', backgroundColor:'transparent', tension:0, borderDash:[6,4] }
    ]},
    options:{ responsive:true, maintainAspectRatio:false }
  });

  // Env score gauge (donut half)
  const t = totals();
  const score = Math.min(100, Math.max(0, 100 - (t.energyIntensity*40) - (t.wasteIntensity*30) + t.renewablePct*0.3 + t.recycleRate*0.2));
  makeChart('ch-score', {
    type:'doughnut',
    data:{ labels:['Score','Remaining'], datasets:[{ data:[score, 100-score], backgroundColor:['#10b981','#e2e8f0'], borderWidth:0 }] },
    options:{ responsive:true, maintainAspectRatio:false, cutout:'70%', circumference:180, rotation:270,
      plugins:{ legend:{display:false}, tooltip:{enabled:false} } },
    plugins:[{
      id:'centerText', afterDraw(chart){
        const {ctx, chartArea} = chart;
        ctx.save(); ctx.fillStyle = chartTextColor(); ctx.textAlign='center';
        ctx.font='bold 28px Inter';
        ctx.fillText(score.toFixed(0), (chartArea.left+chartArea.right)/2, chartArea.bottom-10);
        ctx.font='12px Inter'; ctx.fillStyle='#94a3b8';
        ctx.fillText('Performance Score', (chartArea.left+chartArea.right)/2, chartArea.bottom+8);
        ctx.restore();
      }
    }]
  });

  // Water source mix
  const src = {};
  yearData(DB.data.water,y).forEach(r=>{ src[r.source]=(src[r.source]||0)+r.consumption; });
  makeChart('ch-water-src', {
    type:'pie',
    data:{ labels:Object.keys(src), datasets:[{ data:Object.values(src), backgroundColor:CHART_COLORS }] },
    options:{ responsive:true, maintainAspectRatio:false }
  });

  // Renewable
  makeChart('ch-renew', {
    type:'doughnut',
    data:{ labels:['Solar (Renewable)','Grid + Diesel (Non-Renewable)'],
      datasets:[{ data:[t.renewable, t.electricity+t.genEnergy], backgroundColor:['#10b981','#94a3b8'] }] },
    options:{ responsive:true, maintainAspectRatio:false }
  });

  // Air Emissions by pollutant (doughnut)
  makeChart('ch-air-pol', {
    type:'doughnut',
    data:{ labels:['PM','SO₂','NOx','CO','VOC','CO₂'],
      datasets:[{ data:[t.airPM,t.airSO2,t.airNOx,t.airCO,t.airVOC,t.airCO2],
        backgroundColor:['#8b5cf6','#ef4444','#f59e0b','#0ea5e9','#14b8a6','#94a3b8'] }] },
    options:{ responsive:true, maintainAspectRatio:false }
  });
  // Air Emissions monthly trend (bar)
  makeChart('ch-air-trend', {
    type:'bar',
    data:{ labels:MONTHS, datasets:[
      { label:'Total Mass (kg)', data:monthlySeries(DB.data.air||[],'mass',y), backgroundColor:'#8b5cf6' }
    ]},
    options:{ responsive:true, maintainAspectRatio:false, plugins:{legend:{display:false}} }
  });
};

/* ============ KPI View ============ */
function renderKPIView(){
  const t = totals();
  return `
  <div class="kpi-grid">
    ${kpi('Energy Intensity', t.energyIntensity.toFixed(3)+' kWh/kg','⚡','blue')}
    ${kpi('Water Intensity', t.waterIntensity.toFixed(3)+' m³/kg','💧','teal')}
    ${kpi('Wastewater Intensity', t.wwIntensity.toFixed(3)+' m³/kg','🚿','amber')}
    ${kpi('Natural Gas Intensity', t.gasIntensity.toFixed(4)+' m³/kg','🔥','red')}
    ${kpi('Waste Intensity', t.wasteIntensity.toFixed(4)+' kg/kg','🗑️','purple')}
    ${kpi('Solar %', ((t.solar/(t.totalEnergy||1))*100).toFixed(1)+'%','☀️','green')}
    ${kpi('Renewable %', t.renewablePct.toFixed(1)+'%','🌱','green')}
    ${kpi('Generator %', ((t.genEnergy/(t.totalEnergy||1))*100).toFixed(1)+'%','🔌','amber')}
    ${kpi('Water Recycling %', t.recycleRate.toFixed(1)+'%','♻️','green')}
    ${kpi('Scope 1 CO₂', fmt(t.scope1/1000,2)+' tCO₂','🏭','red')}
    ${kpi('Scope 2 CO₂', fmt(t.scope2/1000,2)+' tCO₂','⚡','red')}
    ${kpi('CO₂ per kg Prod.', t.co2PerKg.toFixed(3)+' kg','📉','indigo')}
    ${kpi('CO₂ per Piece', t.co2PerPc.toFixed(4)+' kg','📉','indigo')}
    ${kpi('Total Production', fmt(t.totalProduction)+' kg','🏭','blue')}
    ${kpi('Total Pieces', fmt(t.totalPieces),'👕','blue')}
  </div>
  <div class="charts-grid">
    <div class="card"><h3>KPI Trend (Monthly)</h3><div class="chart-box tall"><canvas id="ch-kpi-trend"></canvas></div></div>
    <div class="card"><h3>Carbon Emissions Breakdown</h3><div class="chart-box tall"><canvas id="ch-carbon"></canvas></div></div>
  </div>`;
}
window._post_kpi = function(){
  const y = State.yearFilter;
  const prod = monthlySeries(DB.data.production,'quantity',y).map(v=>v||1);
  const elec = monthlySeries(DB.data.energy,'consumption',y);
  const wat = monthlySeries(DB.data.water,'consumption',y);
  const gas = monthlySeries(DB.data.gas,'consumption',y);
  makeChart('ch-kpi-trend', {
    type:'line',
    data:{ labels:MONTHS, datasets:[
      { label:'Energy Intensity', data:elec.map((v,i)=>v/prod[i]), borderColor:'#0ea5e9', tension:.35 },
      { label:'Water Intensity', data:wat.map((v,i)=>v/prod[i]), borderColor:'#14b8a6', tension:.35 },
      { label:'Gas Intensity', data:gas.map((v,i)=>v/prod[i]), borderColor:'#ef4444', tension:.35 },
    ]},
    options:{ responsive:true, maintainAspectRatio:false }
  });
  const t = totals();
  makeChart('ch-carbon', {
    type:'bar',
    data:{ labels:['Natural Gas','Diesel','Electricity (Grid)'],
      datasets:[{ label:'kg CO₂', data:[t.gas*DB.data.emissionFactors.natural_gas, t.diesel*DB.data.emissionFactors.diesel, t.electricity*DB.data.emissionFactors.electricity],
        backgroundColor:['#ef4444','#f59e0b','#0ea5e9'] }] },
    options:{ responsive:true, maintainAspectRatio:false }
  });
};

/* ============ Generic Module Framework ============ */
function moduleToolbar(id, opts={}){
  return `
  <div class="toolbar no-print">
    <select id="${id}-year">
      <option value="all">All Years</option>
      ${YEARS.map(y=>`<option value="${y}" ${y===State.yearFilter?'selected':''}>${y}</option>`).join('')}
    </select>
    <select id="${id}-month">
      <option value="all">All Months</option>
      ${MONTHS.map((m,i)=>`<option value="${i+1}">${m}</option>`).join('')}
    </select>
    ${opts.extraFilter||''}
    <input class="search" id="${id}-search" placeholder="Search..."/>
    <div style="flex:1"></div>
    ${Auth.can('add')?`<button class="btn btn-primary" id="${id}-add">＋ Add Entry</button>`:''}
    ${Auth.can('export')?`
      <button class="btn" id="${id}-pdf">📄 PDF</button>
      <button class="btn" id="${id}-xlsx">📊 Excel</button>
      <button class="btn" id="${id}-csv">📋 CSV</button>
      <button class="btn btn-icon" onclick="window.print()" title="Print">🖨️</button>
    `:''}
  </div>`;
}

function filterRows(rows, id){
  const yr = $('#'+id+'-year')?.value || State.yearFilter;
  const mo = $('#'+id+'-month')?.value || 'all';
  const q = ($('#'+id+'-search')?.value || '').toLowerCase().trim();
  return rows.filter(r=>{
    if (yr!=='all' && r.year!=+yr) return false;
    if (mo!=='all' && r.month!=+mo) return false;
    if (q) {
      const hay = Object.values(r).join(' ').toLowerCase();
      if (!hay.includes(q)) return false;
    }
    return true;
  });
}

function wireModuleToolbar(id, arrKey, cols, addFn){
  const rerender = () => renderRoute();
  $('#'+id+'-year')?.addEventListener('change', e=>{ State.yearFilter = e.target.value==='all'?'all':+e.target.value; rerender(); });
  $('#'+id+'-month')?.addEventListener('change', e=>{ State.monthFilter = e.target.value; rerender(); });
  $('#'+id+'-search')?.addEventListener('input', ()=>rerender());
  $('#'+id+'-add')?.addEventListener('click', addFn);
  $('#'+id+'-pdf')?.addEventListener('click', ()=>exportPDF(id, arrKey, cols));
  $('#'+id+'-xlsx')?.addEventListener('click', ()=>exportXLSX(id, arrKey, cols));
  $('#'+id+'-csv')?.addEventListener('click', ()=>exportCSV(id, arrKey, cols));
}

function exportPDF(name, arrKey, cols){
  const { jsPDF } = window.jspdf;
  const doc = new jsPDF({ orientation:'landscape' });
  doc.setFontSize(14); doc.text(`Utility360 — ${name.toUpperCase()} Report`, 14, 15);
  doc.setFontSize(10); doc.text(`Generated: ${new Date().toLocaleString()}`, 14, 22);
  const rows = filterRows(DB.data[arrKey]||[], name);
  const head = [cols.map(c=>c.label)];
  const body = rows.map(r=>cols.map(c=>c.fmt?c.fmt(r[c.key],r):r[c.key]));
  doc.autoTable({ head, body, startY:28, styles:{fontSize:8}, headStyles:{fillColor:[14,165,233]} });
  doc.save(`utility360-${name}-${Date.now()}.pdf`);
  DB.audit('Export PDF', name, `${rows.length} rows`); DB.save();
  toast('PDF exported');
}
function exportXLSX(name, arrKey, cols){
  const rows = filterRows(DB.data[arrKey]||[], name);
  const data = rows.map(r=>{ const o={}; cols.forEach(c=>{o[c.label]= c.fmt? c.fmt(r[c.key],r):r[c.key];}); return o; });
  const ws = XLSX.utils.json_to_sheet(data);
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, name);
  XLSX.writeFile(wb, `utility360-${name}-${Date.now()}.xlsx`);
  DB.audit('Export Excel', name, `${rows.length} rows`); DB.save();
  toast('Excel exported');
}
function exportCSV(name, arrKey, cols){
  const rows = filterRows(DB.data[arrKey]||[], name);
  const header = cols.map(c=>c.label).join(',');
  const body = rows.map(r=>cols.map(c=>{
    const v = c.fmt?c.fmt(r[c.key],r):r[c.key];
    return '"'+String(v??'').replace(/"/g,'""')+'"';
  }).join(',')).join('\n');
  const blob = new Blob([header+'\n'+body], {type:'text/csv'});
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a'); a.href=url; a.download=`utility360-${name}-${Date.now()}.csv`; a.click();
  URL.revokeObjectURL(url);
  DB.audit('Export CSV', name, `${rows.length} rows`); DB.save();
  toast('CSV exported');
}

/* Modal helper */
function openModal(html, onSubmit, title='Entry'){
  const bd = $('#modal-backdrop');
  const m = $('#modal');
  m.innerHTML = `
    <div class="modal-header"><h3>${title}</h3><button class="icon-btn" id="mod-close">✕</button></div>
    <form id="mod-form">
      <div class="modal-body">${html}</div>
      <div class="modal-footer">
        <button type="button" class="btn" id="mod-cancel">Cancel</button>
        <button type="submit" class="btn btn-primary">Save</button>
      </div>
    </form>`;
  bd.classList.add('open');
  const close = ()=>bd.classList.remove('open');
  $('#mod-close').onclick = close;
  $('#mod-cancel').onclick = close;
  bd.onclick = e=>{ if (e.target===bd) close(); };
  $('#mod-form').onsubmit = e=>{
    e.preventDefault();
    const fd = new FormData(e.target);
    const obj = {};
    for (const [k,v] of fd.entries()) obj[k]=v;
    onSubmit(obj, close);
  };
}

function selectField(name, label, options, value=''){
  return `<div class="form-group"><label>${label}</label>
    <select name="${name}" required>${options.map(o=>`<option value="${o}" ${o===value?'selected':''}>${o}</option>`).join('')}</select></div>`;
}
function inputField(name, label, type='text', value='', extra=''){
  return `<div class="form-group"><label>${label}</label>
    <input name="${name}" type="${type}" value="${value===undefined||value===null?'':value}" ${extra} ${type==='number'?'step="any"':''}/></div>`;
}
function textareaField(name, label, value=''){
  return `<div class="form-group"><label>${label}</label><textarea name="${name}">${value||''}</textarea></div>`;
}

function actionCol(id, arrKey, moduleName, editFn){
  const canAdd = Auth.can('add');
  const canDel = Auth.can('delete');
  if (!canAdd && !canDel) return '';
  return `<td class="no-print">
    ${canAdd?`<button class="btn btn-sm" onclick="_editRow('${arrKey}',${id},${editFn.name})">✏️</button>`:''}
    ${canDel?`<button class="btn btn-sm btn-danger" onclick="_deleteRow('${arrKey}',${id},'${moduleName}')">🗑️</button>`:''}
  </td>`;
}
window._deleteRow = function(arrKey, id, moduleName){
  if (!confirmDlg('Delete this entry?')) return;
  DB.data[arrKey] = DB.data[arrKey].filter(r=>r.id!==id);
  DB.audit('Delete', moduleName, 'ID '+id); DB.save();
  toast('Deleted','warning'); renderRoute();
};

/* ============ Module: Energy ============ */
function renderModuleEnergy(el){
  const rows = filterRows(DB.data.energy, 'energy');
  const y = State.yearFilter==='all'?CURRENT_YEAR:State.yearFilter;
  const deptTotals = {};
  yearData(DB.data.energy,y).forEach(r=>{ deptTotals[r.department]=(deptTotals[r.department]||0)+r.consumption; });
  const sorted = Object.entries(deptTotals).sort((a,b)=>b[1]-a[1]);
  const highest = sorted[0]||['-',0]; const lowest = sorted[sorted.length-1]||['-',0];
  const total = sum(rows,'consumption'); const totalCost = sum(rows,'total');
  const annualTotal = sum(yearData(DB.data.energy,y),'consumption');
  const prodTotal = sum(yearData(DB.data.production,y),'quantity');
  const piecesTotal = sum(yearData(DB.data.production,y),'pieces');
  const cols = [
    {key:'month', label:'Month', fmt:v=>MONTHS[v-1]},
    {key:'year', label:'Year'},
    {key:'department', label:'Department'},
    {key:'meter', label:'Meter #'},
    {key:'consumption', label:'Consumption (kWh)', fmt:v=>fmt(v)},
    {key:'cost', label:'Cost/Unit', fmt:v=>fmt(v,2)},
    {key:'total', label:'Total Cost', fmt:v=>fmt(v)},
    {key:'remarks', label:'Remarks'},
  ];

  const html = `
  ${moduleToolbar('energy')}
  <div class="kpi-grid">
    ${kpi('Filtered Consumption', fmt(total)+' kWh','⚡','blue')}
    ${kpi('Annual Total', fmt(annualTotal)+' kWh','📅','blue')}
    ${kpi('Total Cost', fmt(totalCost)+' ৳','💰','amber')}
    ${kpi('Avg Monthly', fmt(annualTotal/12)+' kWh','📊','indigo')}
    ${kpi('Avg Daily', fmt(annualTotal/365)+' kWh','📆','indigo')}
    ${kpi('kWh per kg', prodTotal>0?(annualTotal/prodTotal).toFixed(3):'-','⚙️','purple')}
    ${kpi('kWh per Piece', piecesTotal>0?(annualTotal/piecesTotal).toFixed(3):'-','👕','purple')}
    ${kpi('Highest Consumer', highest[0],'🔴','red', fmt(highest[1])+' kWh')}
    ${kpi('Lowest Consumer', lowest[0],'🟢','green', fmt(lowest[1])+' kWh')}
  </div>
  <div class="charts-grid">
    <div class="card"><h3>Monthly Consumption Trend</h3><div class="chart-box"><canvas id="ec-trend"></canvas></div></div>
    <div class="card"><h3>Department % Share</h3><div class="chart-box"><canvas id="ec-share"></canvas></div></div>
  </div>
  <div class="card">
    <h3>Energy Consumption Records <span class="badge badge-blue">${rows.length} entries</span></h3>
    <div class="table-wrap">
      <table>
        <thead><tr>${cols.map(c=>`<th>${c.label}</th>`).join('')}${Auth.can('add')||Auth.can('delete')?'<th class="no-print">Actions</th>':''}</tr></thead>
        <tbody>${rows.length?rows.map(r=>`<tr>${cols.map(c=>`<td>${c.fmt?c.fmt(r[c.key],r):(r[c.key]??'')}</td>`).join('')}${actionCol(r.id,'energy','Energy',editEnergy)}</tr>`).join(''):`<tr><td colspan="${cols.length+1}" class="empty">No records</td></tr>`}</tbody>
      </table>
    </div>
  </div>`;
  el.innerHTML = html;
  wireModuleToolbar('energy','energy',cols, ()=>editEnergy());

  // Charts
  const consumeSeries = monthlySeries(DB.data.energy,'consumption',y);
  makeChart('ec-trend', { type:'line',
    data:{ labels:MONTHS, datasets:[{ label:'kWh', data:consumeSeries, borderColor:'#0ea5e9', backgroundColor:'rgba(14,165,233,.15)', fill:true, tension:.35 }]},
    options:{ responsive:true, maintainAspectRatio:false }
  });
  makeChart('ec-share', { type:'doughnut',
    data:{ labels:sorted.map(x=>x[0]), datasets:[{ data:sorted.map(x=>x[1]), backgroundColor:CHART_COLORS }]},
    options:{ responsive:true, maintainAspectRatio:false }
  });
}
window._editRow = function(arrKey, id, fnName){
  const row = DB.data[arrKey].find(r=>r.id===id);
  window[fnName.name || fnName](row);
};
function editEnergy(row){
  const r = row || { month:1, year:CURRENT_YEAR, department:ENERGY_DEPTS[0], meter:'', consumption:0, cost:12.5, total:0, remarks:'' };
  const html = `
    <div class="form-row">
      ${selectField('month','Month',MONTHS.map((m,i)=>i+1+'|'+m).map(x=>x.split('|')[1]), MONTHS[r.month-1])}
      <div class="form-group"><label>Year</label><select name="year">${YEARS.map(y=>`<option ${y===r.year?'selected':''}>${y}</option>`).join('')}</select></div>
    </div>
    ${selectField('department','Department',ENERGY_DEPTS, r.department)}
    <div class="form-row">
      ${inputField('meter','Meter Number','text', r.meter)}
      ${inputField('consumption','Consumption (kWh)','number', r.consumption)}
    </div>
    <div class="form-row">
      ${inputField('cost','Cost per Unit (৳)','number', r.cost)}
      ${inputField('total','Total Cost (auto)','number', r.total, 'readonly')}
    </div>
    ${textareaField('remarks','Remarks', r.remarks)}
  `;
  openModal(html, (obj, close)=>{
    const monthIdx = MONTHS.indexOf(obj.month)+1;
    const consumption = +obj.consumption;
    const total = consumption * +obj.cost;
    const rec = { id: r.id||uid(), month:monthIdx, year:+obj.year, department:obj.department,
      meter:obj.meter, consumption, cost:+obj.cost, total, remarks:obj.remarks };
    if (row) { Object.assign(row, rec); DB.audit('Update','Energy','Meter '+rec.meter); }
    else { DB.data.energy.push(rec); DB.audit('Create','Energy','Meter '+rec.meter); }
    DB.save(); close(); toast('Saved'); renderRoute();
  }, row?'Edit Energy Record':'Add Energy Record');
}

/* ============ Module: Water ============ */
function renderModuleWater(el){
  const rows = filterRows(DB.data.water, 'water');
  const y = State.yearFilter==='all'?CURRENT_YEAR:State.yearFilter;
  const total = sum(rows,'consumption');
  const annual = sum(yearData(DB.data.water,y),'consumption');
  const prod = sum(yearData(DB.data.production,y),'quantity');
  const pcs = sum(yearData(DB.data.production,y),'pieces');
  const bySource = {}; yearData(DB.data.water,y).forEach(r=>bySource[r.source]=(bySource[r.source]||0)+r.consumption);
  const byDept = {}; yearData(DB.data.water,y).forEach(r=>{ const d = r.department || r.area || '—'; byDept[d]=(byDept[d]||0)+r.consumption; });
  const cols = [
    {key:'month', label:'Month', fmt:v=>MONTHS[v-1]},
    {key:'year', label:'Year'},
    {key:'source', label:'Source'},
    {key:'department', label:'Department', fmt:(v,r)=> v || '—'},
    {key:'consumption', label:'Consumption', fmt:(v,r)=> fmt(v)+' '+(r.unit||'m³')},
    {key:'unit', label:'Unit', fmt:v=> v || 'm³'},
    {key:'cost', label:'Cost/Unit', fmt:v=>fmt(v,2)},
    {key:'total', label:'Monthly Cost', fmt:v=>fmt(v)},
  ];
  el.innerHTML = `
  ${moduleToolbar('water')}
  <div class="kpi-grid">
    ${kpi('Filtered Total','~'+fmt(total)+' m³','💧','teal')}
    ${kpi('Annual Total', fmt(annual)+' m³','📅','teal')}
    ${kpi('Water Intensity', prod>0?(annual/prod).toFixed(3)+' m³/kg':'-','📊','indigo')}
    ${kpi('m³ per Piece', pcs>0?(annual/pcs).toFixed(4):'-','👕','purple')}
    ${kpi('Daily Average', fmt(annual/365)+' m³','📆','blue')}
    ${kpi('Monthly Average', fmt(annual/12)+' m³','📅','blue')}
  </div>
  <div class="charts-grid">
    <div class="card"><h3>Water Sources</h3><div class="chart-box"><canvas id="wc-src"></canvas></div></div>
    <div class="card"><h3>Consumption by Department</h3><div class="chart-box"><canvas id="wc-area"></canvas></div></div>
    <div class="card"><h3>Monthly Water Trend</h3><div class="chart-box"><canvas id="wc-trend"></canvas></div></div>
  </div>
  <div class="card">
    <h3>Water Consumption Records <span class="badge badge-blue">${rows.length}</span></h3>
    <div class="table-wrap">
      <table>
        <thead><tr>${cols.map(c=>`<th>${c.label}</th>`).join('')}${Auth.can('add')||Auth.can('delete')?'<th class="no-print">Actions</th>':''}</tr></thead>
        <tbody>${rows.length?rows.map(r=>`<tr>${cols.map(c=>`<td>${c.fmt?c.fmt(r[c.key],r):(r[c.key]??'')}</td>`).join('')}${actionCol(r.id,'water','Water',editWater)}</tr>`).join(''):`<tr><td colspan="${cols.length+1}" class="empty">No records</td></tr>`}</tbody>
      </table>
    </div>
  </div>`;
  wireModuleToolbar('water','water',cols,()=>editWater());
  makeChart('wc-src',{ type:'doughnut', data:{ labels:Object.keys(bySource), datasets:[{data:Object.values(bySource), backgroundColor:CHART_COLORS}]}, options:{responsive:true, maintainAspectRatio:false}});
  makeChart('wc-area',{ type:'bar', data:{ labels:Object.keys(byDept), datasets:[{label:'Consumption', data:Object.values(byDept), backgroundColor:'#14b8a6'}]}, options:{responsive:true, maintainAspectRatio:false, plugins:{legend:{display:false}}}});
  makeChart('wc-trend',{ type:'line', data:{ labels:MONTHS, datasets:[{label:'m³', data:monthlySeries(DB.data.water,'consumption',y), borderColor:'#14b8a6', backgroundColor:'rgba(20,184,166,.15)', fill:true, tension:.35}]}, options:{responsive:true, maintainAspectRatio:false}});
}
function editWater(row){
  const r = row || { month:1,year:CURRENT_YEAR,source:WATER_SOURCES[0],department:WATER_DEPTS[0],unit:'m³',consumption:0,cost:0.85,total:0 };
  const currentDept = r.department || r.area || WATER_DEPTS[0];
  const currentUnit = r.unit || 'm³';
  const html = `
    <div class="form-row">
      ${selectField('month','Month',MONTHS, MONTHS[r.month-1])}
      <div class="form-group"><label>Year</label><select name="year">${YEARS.map(y=>`<option ${y===r.year?'selected':''}>${y}</option>`).join('')}</select></div>
    </div>
    <div class="form-row">
      ${selectField('source','Source',WATER_SOURCES, r.source)}
      ${selectField('department','Department',WATER_DEPTS, currentDept)}
    </div>
    <div class="form-row">
      ${inputField('consumption','Consumption','number', r.consumption)}
      ${selectField('unit','Unit',WATER_UNITS, currentUnit)}
    </div>
    <div class="form-row">
      ${inputField('cost','Cost per Unit','number', r.cost)}
      ${inputField('total','Total Cost (auto)','number', r.total, 'readonly')}
    </div>`;
  openModal(html, (obj, close)=>{
    const consumption = +obj.consumption;
    const total = consumption * +obj.cost;
    const rec = { id:r.id||uid(), month:MONTHS.indexOf(obj.month)+1, year:+obj.year,
      source:obj.source, department:obj.department, unit:obj.unit||'m³',
      consumption, cost:+obj.cost, total };
    if (row){ Object.assign(row,rec); DB.audit('Update','Water',rec.source); } else { DB.data.water.push(rec); DB.audit('Create','Water',rec.source); }
    DB.save(); close(); toast('Saved'); renderRoute();
  }, row?'Edit Water Record':'Add Water Record');
}

/* ============ Module: Wastewater ============ */
function renderModuleWastewater(el){
  const rows = filterRows(DB.data.wastewater, 'wastewater');
  const y = State.yearFilter==='all'?CURRENT_YEAR:State.yearFilter;
  const yr = yearData(DB.data.wastewater,y);
  const totalIn = sum(yr,'influent'), totalOut = sum(yr,'effluent');
  const eff = totalIn>0 ? ((totalIn-totalOut)/totalIn*100) : 0;
  const prod = sum(yearData(DB.data.production,y),'quantity');
  const byType = {}; yr.forEach(r=>byType[r.department||r.type]=(byType[r.department||r.type]||0)+r.effluent);
  const cols = [
    {key:'month', label:'Month', fmt:v=>MONTHS[v-1]},
    {key:'year', label:'Year'},
    {key:'department', label:'Department', fmt:(v,r)=> v || r.type || '—'},
    {key:'influent', label:'Influent', fmt:(v,r)=> fmt(v)+' '+(r.unit||'m³')},
    {key:'effluent', label:'Effluent', fmt:(v,r)=> fmt(v)+' '+(r.unit||'m³')},
    {key:'unit', label:'Unit', fmt:v=> v || 'm³'},
  ];
  el.innerHTML = `
  ${moduleToolbar('wastewater')}
  <div class="kpi-grid">
    ${kpi('Total Wastewater', fmt(totalOut)+' m³','🚿','amber')}
    ${kpi('Influent', fmt(totalIn)+' m³','⬅️','blue')}
    ${kpi('Effluent', fmt(totalOut)+' m³','➡️','amber')}
    ${kpi('Treatment Efficiency', eff.toFixed(1)+'%','⚙️','green')}
    ${kpi('WW Intensity', prod>0?(totalOut/prod).toFixed(3):'-','📊','indigo')}
    ${kpi('WW per kg', prod>0?(totalOut/prod).toFixed(3)+' m³/kg':'-','📉','purple')}
  </div>
  <div class="charts-grid">
    <div class="card"><h3>Influent vs Effluent (Monthly)</h3><div class="chart-box"><canvas id="ww-io"></canvas></div></div>
    <div class="card"><h3>Wastewater by Department</h3><div class="chart-box"><canvas id="ww-type"></canvas></div></div>
  </div>
  <div class="card">
    <h3>Wastewater Records <span class="badge badge-amber">${rows.length}</span></h3>
    <div class="table-wrap"><table>
      <thead><tr>${cols.map(c=>`<th>${c.label}</th>`).join('')}${Auth.can('add')||Auth.can('delete')?'<th class="no-print">Actions</th>':''}</tr></thead>
      <tbody>${rows.length?rows.map(r=>`<tr>${cols.map(c=>`<td>${c.fmt?c.fmt(r[c.key],r):(r[c.key]??'')}</td>`).join('')}${actionCol(r.id,'wastewater','Wastewater',editWW)}</tr>`).join(''):`<tr><td colspan="${cols.length+1}" class="empty">No records</td></tr>`}</tbody>
    </table></div>
  </div>`;
  wireModuleToolbar('wastewater','wastewater',cols,()=>editWW());
  makeChart('ww-io',{ type:'bar', data:{ labels:MONTHS, datasets:[
    {label:'Influent', data:monthlySeries(DB.data.wastewater,'influent',y), backgroundColor:'#0ea5e9'},
    {label:'Effluent', data:monthlySeries(DB.data.wastewater,'effluent',y), backgroundColor:'#f59e0b'}
  ]}, options:{responsive:true, maintainAspectRatio:false}});
  makeChart('ww-type',{ type:'pie', data:{ labels:Object.keys(byType), datasets:[{data:Object.values(byType), backgroundColor:CHART_COLORS}]}, options:{responsive:true, maintainAspectRatio:false}});
}
function editWW(row){
  const r = row||{ month:1,year:CURRENT_YEAR,department:WASTEWATER_DEPTS[0],unit:'m³',influent:0,effluent:0 };
  const currentDept = r.department || r.type || WASTEWATER_DEPTS[0];
  const currentUnit = r.unit || 'm³';
  const html = `
    <div class="form-row">
      ${selectField('month','Month',MONTHS,MONTHS[r.month-1])}
      <div class="form-group"><label>Year</label><select name="year">${YEARS.map(y=>`<option ${y===r.year?'selected':''}>${y}</option>`).join('')}</select></div>
    </div>
    <div class="form-row">
      ${selectField('department','Department',WASTEWATER_DEPTS,currentDept)}
      ${selectField('unit','Unit',WASTEWATER_UNITS,currentUnit)}
    </div>
    <div class="form-row">
      ${inputField('influent','Influent','number',r.influent)}
      ${inputField('effluent','Effluent','number',r.effluent)}
    </div>`;
  openModal(html,(obj,close)=>{
    const rec = { id:r.id||uid(), month:MONTHS.indexOf(obj.month)+1, year:+obj.year, department:obj.department, unit:obj.unit||'m³', influent:+obj.influent, effluent:+obj.effluent };
    if (row){Object.assign(row,rec); DB.audit('Update','Wastewater',rec.department);} else {DB.data.wastewater.push(rec); DB.audit('Create','Wastewater',rec.department);}
    DB.save(); close(); toast('Saved'); renderRoute();
  }, row?'Edit Wastewater':'Add Wastewater');
}

/* ============ Module: Water Recycling ============ */
function renderModuleRecycle(el){
  const rows = filterRows(DB.data.recycle, 'recycle');
  const y = State.yearFilter==='all'?CURRENT_YEAR:State.yearFilter;
  const totalRecycled = sum(yearData(DB.data.recycle,y),'quantity');
  const totalWater = sum(yearData(DB.data.water,y),'consumption');
  const recyclePct = totalWater>0 ? (totalRecycled/(totalWater+totalRecycled)*100) : 0;
  const freshReduction = totalRecycled;
  const cols = [
    {key:'month',label:'Month',fmt:v=>MONTHS[v-1]},
    {key:'year',label:'Year'},
    {key:'type',label:'Type'},
    {key:'quantity',label:'Quantity (m³)',fmt:v=>fmt(v)},
  ];
  const byType = {}; yearData(DB.data.recycle,y).forEach(r=>byType[r.type]=(byType[r.type]||0)+r.quantity);
  el.innerHTML = `
  ${moduleToolbar('recycle')}
  <div class="kpi-grid">
    ${kpi('Total Recycled', fmt(totalRecycled)+' m³','♻️','green')}
    ${kpi('Recycling %', recyclePct.toFixed(1)+'%','📈','green')}
    ${kpi('Water Saving', fmt(freshReduction)+' m³','💧','teal')}
    ${kpi('Fresh Water Reduction', freshReduction>0? '~'+((freshReduction/(totalWater+freshReduction))*100).toFixed(1)+'%':'-','📉','blue')}
  </div>
  <div class="charts-grid">
    <div class="card"><h3>Recycling Type Distribution</h3><div class="chart-box"><canvas id="rc-type"></canvas></div></div>
    <div class="card"><h3>Three-Year Recycling Trend</h3><div class="chart-box"><canvas id="rc-3yr"></canvas></div></div>
  </div>
  <div class="card">
    <h3>Water Recycling Records <span class="badge badge-green">${rows.length}</span></h3>
    <div class="table-wrap"><table>
      <thead><tr>${cols.map(c=>`<th>${c.label}</th>`).join('')}${Auth.can('add')||Auth.can('delete')?'<th class="no-print">Actions</th>':''}</tr></thead>
      <tbody>${rows.length?rows.map(r=>`<tr>${cols.map(c=>`<td>${c.fmt?c.fmt(r[c.key],r):(r[c.key]??'')}</td>`).join('')}${actionCol(r.id,'recycle','Recycle',editRecycle)}</tr>`).join(''):`<tr><td colspan="${cols.length+1}" class="empty">No records</td></tr>`}</tbody>
    </table></div>
  </div>`;
  wireModuleToolbar('recycle','recycle',cols,()=>editRecycle());
  makeChart('rc-type',{ type:'doughnut', data:{labels:Object.keys(byType),datasets:[{data:Object.values(byType), backgroundColor:CHART_COLORS}]}, options:{responsive:true, maintainAspectRatio:false}});
  makeChart('rc-3yr',{ type:'bar', data:{ labels:MONTHS, datasets:YEARS.map((y,i)=>({label:y, data:monthlySeries(DB.data.recycle,'quantity',y), backgroundColor:CHART_COLORS[i]}))}, options:{responsive:true,maintainAspectRatio:false}});
}
function editRecycle(row){
  const r = row||{ month:1,year:CURRENT_YEAR,type:RECYCLE_TYPES[0],quantity:0 };
  const html = `
    <div class="form-row">
      ${selectField('month','Month',MONTHS,MONTHS[r.month-1])}
      <div class="form-group"><label>Year</label><select name="year">${YEARS.map(y=>`<option ${y===r.year?'selected':''}>${y}</option>`).join('')}</select></div>
    </div>
    ${selectField('type','Type',RECYCLE_TYPES,r.type)}
    ${inputField('quantity','Quantity (m³)','number',r.quantity)}`;
  openModal(html,(obj,close)=>{
    const rec = { id:r.id||uid(), month:MONTHS.indexOf(obj.month)+1, year:+obj.year, type:obj.type, quantity:+obj.quantity };
    if (row){Object.assign(row,rec); DB.audit('Update','Recycle',rec.type);} else {DB.data.recycle.push(rec); DB.audit('Create','Recycle',rec.type);}
    DB.save(); close(); toast('Saved'); renderRoute();
  }, row?'Edit Recycling':'Add Recycling');
}

/* ============ Module: Natural Gas ============ */
function renderModuleGas(el){
  const rows = filterRows(DB.data.gas, 'gas');
  const y = State.yearFilter==='all'?CURRENT_YEAR:State.yearFilter;
  const yr = yearData(DB.data.gas,y);
  const annual = sum(yr,'consumption'); const totalCost = sum(yr,'total');
  const prod = sum(yearData(DB.data.production,y),'quantity');
  const byDept = {}; yr.forEach(r=>byDept[r.department]=(byDept[r.department]||0)+r.consumption);
  const cols = [
    {key:'month',label:'Month',fmt:v=>MONTHS[v-1]},
    {key:'year',label:'Year'},
    {key:'department',label:'Department'},
    {key:'meter',label:'Meter'},
    {key:'consumption',label:'Consumption',fmt:(v,r)=>fmt(v) + ' ' + (r.unit||'m³')},
    {key:'unit',label:'Unit'},
    {key:'cost',label:'Cost/unit',fmt:v=>fmt(v,2)},
    {key:'total',label:'Total Cost',fmt:v=>fmt(v)},
  ];
  el.innerHTML = `
  ${moduleToolbar('gas')}
  <div class="kpi-grid">
    ${kpi('Annual Gas','~'+fmt(annual)+' m³','🔥','red')}
    ${kpi('Monthly Avg', fmt(annual/12)+' m³','📅','red')}
    ${kpi('Total Cost', fmt(totalCost)+' ৳','💰','amber')}
    ${kpi('Gas Intensity', prod>0?(annual/prod).toFixed(4)+' m³/kg':'-','📊','indigo')}
  </div>
  <div class="charts-grid">
    <div class="card"><h3>Monthly Gas Trend</h3><div class="chart-box"><canvas id="gs-trend"></canvas></div></div>
    <div class="card"><h3>Department Comparison</h3><div class="chart-box"><canvas id="gs-dept"></canvas></div></div>
  </div>
  <div class="card">
    <h3>Natural Gas Records <span class="badge badge-red">${rows.length}</span></h3>
    <div class="table-wrap"><table>
      <thead><tr>${cols.map(c=>`<th>${c.label}</th>`).join('')}${Auth.can('add')||Auth.can('delete')?'<th class="no-print">Actions</th>':''}</tr></thead>
      <tbody>${rows.length?rows.map(r=>`<tr>${cols.map(c=>`<td>${c.fmt?c.fmt(r[c.key],r):(r[c.key]??'')}</td>`).join('')}${actionCol(r.id,'gas','Gas',editGas)}</tr>`).join(''):`<tr><td colspan="${cols.length+1}" class="empty">No records</td></tr>`}</tbody>
    </table></div>
  </div>`;
  wireModuleToolbar('gas','gas',cols,()=>editGas());
  makeChart('gs-trend',{ type:'line', data:{labels:MONTHS, datasets:[{label:'m³', data:monthlySeries(DB.data.gas,'consumption',y), borderColor:'#ef4444', backgroundColor:'rgba(239,68,68,.15)', fill:true, tension:.35}]}, options:{responsive:true,maintainAspectRatio:false}});
  makeChart('gs-dept',{ type:'bar', data:{ labels:Object.keys(byDept), datasets:[{label:'m³', data:Object.values(byDept), backgroundColor:CHART_COLORS}]}, options:{responsive:true, maintainAspectRatio:false, plugins:{legend:{display:false}}}});
}
function editGas(row){
  const r = row||{ month:1,year:CURRENT_YEAR,department:GAS_DEPTS[0],meter:'',unit:GAS_UNITS[0],consumption:0,cost:0.42,total:0 };
  const html = `
    <div class="form-row">
      ${selectField('month','Month',MONTHS,MONTHS[r.month-1])}
      <div class="form-group"><label>Year</label><select name="year">${YEARS.map(y=>`<option ${y===r.year?'selected':''}>${y}</option>`).join('')}</select></div>
    </div>
    <div class="form-row">
      ${selectField('department','Department',GAS_DEPTS,r.department)}
      ${selectField('unit','Unit',GAS_UNITS,r.unit||'m³')}
    </div>
    <div class="form-row">
      ${inputField('meter','Meter #','text',r.meter)}
      ${inputField('consumption','Consumption','number',r.consumption)}
    </div>
    ${inputField('cost','Cost per unit','number',r.cost)}`;
  openModal(html,(obj,close)=>{
    const consumption = +obj.consumption;
    const total = consumption*+obj.cost;
    const rec = { id:r.id||uid(), month:MONTHS.indexOf(obj.month)+1, year:+obj.year, department:obj.department, meter:obj.meter, unit:obj.unit||'m³', consumption, cost:+obj.cost, total };
    if (row){Object.assign(row,rec); DB.audit('Update','Gas',rec.department);} else {DB.data.gas.push(rec); DB.audit('Create','Gas',rec.department);}
    DB.save(); close(); toast('Saved'); renderRoute();
  }, row?'Edit Gas Record':'Add Gas Record');
}

/* ============ Module: Steam Production ============ */
function renderModuleSteam(el){
  const rows = filterRows(DB.data.steam, 'steam');
  const y = State.yearFilter==='all'?CURRENT_YEAR:State.yearFilter;
  const yr = yearData(DB.data.steam,y);
  const totalGen = sum(yr,'generation');
  const totalCons = sum(yr,'consumption');
  const totalFuel = sum(yr,'fuelUsed');
  const totalCost = sum(yr,'total') || sum(yr,'cost');
  const prod = sum(yearData(DB.data.production,y),'quantity');
  const byDept = {}; yr.forEach(r=>byDept[r.department]=(byDept[r.department]||0)+r.consumption);
  const bySource = {}; yr.forEach(r=>bySource[r.source]=(bySource[r.source]||0)+r.generation);
  const cols = [
    {key:'month',label:'Month',fmt:v=>MONTHS[v-1]},
    {key:'year',label:'Year'},
    {key:'department',label:'Department'},
    {key:'source',label:'Source'},
    {key:'generation',label:'Generated (kg)',fmt:v=>fmt(v)},
    {key:'consumption',label:'Consumed (kg)',fmt:v=>fmt(v)},
    {key:'fuelUsed',label:'Fuel (m³/L)',fmt:v=>fmt(v)},
    {key:'cost',label:'Cost (৳)',fmt:v=>fmt(v)},
  ];
  el.innerHTML = `
  ${moduleToolbar('steam')}
  <div class="kpi-grid">
    ${kpi('Total Steam Generated', fmt(totalGen)+' kg','♨️','red')}
    ${kpi('Total Steam Consumed', fmt(totalCons)+' kg','🌡️','amber')}
    ${kpi('Losses', fmt(totalGen-totalCons)+' kg','⚠️','red', totalGen>0?(((totalGen-totalCons)/totalGen)*100).toFixed(1)+'%':'-')}
    ${kpi('Fuel Used', fmt(totalFuel),'⛽','amber')}
    ${kpi('Steam Cost', fmt(totalCost)+' ৳','💰','amber')}
    ${kpi('Steam Intensity', prod>0?(totalCons/prod).toFixed(3)+' kg/kg':'-','📊','indigo')}
    ${kpi('Monthly Average', fmt(totalCons/12)+' kg','📅','blue')}
  </div>
  <div class="charts-grid">
    <div class="card"><h3>Monthly Steam Trend</h3><div class="chart-box"><canvas id="st-trend"></canvas></div></div>
    <div class="card"><h3>Consumption by Department</h3><div class="chart-box"><canvas id="st-dept"></canvas></div></div>
    <div class="card"><h3>Generation by Source</h3><div class="chart-box"><canvas id="st-src"></canvas></div></div>
    <div class="card"><h3>Generation vs Consumption</h3><div class="chart-box"><canvas id="st-gc"></canvas></div></div>
  </div>
  <div class="card">
    <h3>Steam Production Records <span class="badge badge-red">${rows.length}</span></h3>
    <div class="table-wrap"><table>
      <thead><tr>${cols.map(c=>`<th>${c.label}</th>`).join('')}${(Auth.can('add')||Auth.can('delete'))?'<th class="no-print">Actions</th>':''}</tr></thead>
      <tbody>${rows.length?rows.map(r=>`<tr>${cols.map(c=>`<td>${c.fmt?c.fmt(r[c.key],r):(r[c.key]??'')}</td>`).join('')}${actionCol(r.id,'steam','Steam',editSteam)}</tr>`).join(''):`<tr><td colspan="${cols.length+1}" class="empty">No records</td></tr>`}</tbody>
    </table></div>
  </div>`;
  wireModuleToolbar('steam','steam',cols,()=>editSteam());
  makeChart('st-trend',{ type:'line', data:{labels:MONTHS, datasets:[
    {label:'Generated (kg)', data:monthlySeries(DB.data.steam,'generation',y), borderColor:'#ef4444', backgroundColor:'rgba(239,68,68,.15)', fill:true, tension:.35},
    {label:'Consumed (kg)', data:monthlySeries(DB.data.steam,'consumption',y), borderColor:'#f59e0b', backgroundColor:'rgba(245,158,11,.15)', fill:true, tension:.35}
  ]}, options:{responsive:true,maintainAspectRatio:false}});
  makeChart('st-dept',{ type:'bar', data:{labels:Object.keys(byDept), datasets:[{label:'kg', data:Object.values(byDept), backgroundColor:CHART_COLORS}]}, options:{responsive:true,maintainAspectRatio:false, plugins:{legend:{display:false}}}});
  makeChart('st-src',{ type:'doughnut', data:{labels:Object.keys(bySource), datasets:[{data:Object.values(bySource), backgroundColor:CHART_COLORS}]}, options:{responsive:true,maintainAspectRatio:false}});
  makeChart('st-gc',{ type:'bar', data:{labels:MONTHS, datasets:[
    {label:'Generated', data:monthlySeries(DB.data.steam,'generation',y), backgroundColor:'#ef4444'},
    {label:'Consumed', data:monthlySeries(DB.data.steam,'consumption',y), backgroundColor:'#f59e0b'}
  ]}, options:{responsive:true,maintainAspectRatio:false}});
}
function editSteam(row){
  const r = row||{ month:1,year:CURRENT_YEAR,department:STEAM_DEPTS[0],source:STEAM_SOURCES[0],generation:0,consumption:0,fuelUsed:0,cost:0,remarks:'' };
  const html = `
    <div class="form-row">
      ${selectField('month','Month',MONTHS,MONTHS[r.month-1])}
      <div class="form-group"><label>Year</label><select name="year">${YEARS.map(y=>`<option ${y===r.year?'selected':''}>${y}</option>`).join('')}</select></div>
    </div>
    <div class="form-row">
      ${selectField('department','Department',STEAM_DEPTS,r.department)}
      ${selectField('source','Source',STEAM_SOURCES,r.source)}
    </div>
    <div class="form-row">
      ${inputField('generation','Steam Generated (kg)','number',r.generation)}
      ${inputField('consumption','Steam Consumed (kg)','number',r.consumption)}
    </div>
    <div class="form-row">
      ${inputField('fuelUsed','Fuel Used','number',r.fuelUsed)}
      ${inputField('cost','Cost (৳)','number',r.cost)}
    </div>
    ${textareaField('remarks','Remarks',r.remarks)}`;
  openModal(html,(obj,close)=>{
    const rec = { id:r.id||uid(), month:MONTHS.indexOf(obj.month)+1, year:+obj.year,
      department:obj.department, source:obj.source, generation:+obj.generation, consumption:+obj.consumption,
      fuelUsed:+obj.fuelUsed, cost:+obj.cost, remarks:obj.remarks };
    if (row){Object.assign(row,rec); DB.audit('Update','Steam',rec.department);} else {DB.data.steam.push(rec); DB.audit('Create','Steam',rec.department);}
    DB.save(); close(); toast('Saved'); renderRoute();
  }, row?'Edit Steam Record':'Add Steam Record');
}

/* ============ Module: Energy Production (Solar + Generator) ============ */
function renderModuleProduction(el){
  const y = State.yearFilter==='all'?CURRENT_YEAR:State.yearFilter;
  const solar = filterRows(DB.data.solar,'production');
  const gen = filterRows(DB.data.generator,'production');
  const solarTotal = sum(yearData(DB.data.solar,y),'monthly');
  const genTotal = sum(yearData(DB.data.generator,y),'energy');
  const dieselTotal = sum(yearData(DB.data.generator,y),'diesel');
  const gridElec = sum(yearData(DB.data.energy,y),'consumption');
  const totalEnergy = solarTotal + genTotal + gridElec;
  const renewPct = totalEnergy>0?(solarTotal/totalEnergy*100):0;
  const co2Reduction = solarTotal * DB.data.emissionFactors.electricity;

  const solarCols = [
    {key:'month',label:'Month',fmt:v=>MONTHS[v-1]},
    {key:'year',label:'Year'},
    {key:'dailyAvg',label:'Daily Avg (kWh)'},
    {key:'monthly',label:'Monthly (kWh)',fmt:v=>fmt(v)},
    {key:'hours',label:'Op. Hours'},
  ];
  const genCols = [
    {key:'month',label:'Month',fmt:v=>MONTHS[v-1]},
    {key:'year',label:'Year'},
    {key:'fuel',label:'Fuel',fmt:(v,r)=> v || (r.fuel==='Natural Gas'?'Natural Gas':'Diesel')},
    {key:'hours',label:'Running Hours'},
    {key:'diesel',label:'Fuel Qty',fmt:(v,r)=> fmt(v) + ' ' + ((r.fuel==='Natural Gas')?'m³':'L')},
    {key:'energy',label:'Energy (kWh)',fmt:v=>fmt(v)},
    {key:'efficiency',label:'Efficiency',fmt:(v,r)=> v + ' kWh/' + ((r.fuel==='Natural Gas')?'m³':'L')},
    {key:'loading',label:'Loading %'},
  ];
  el.innerHTML = `
  ${moduleToolbar('production')}
  <div class="kpi-grid">
    ${kpi('Solar Generated', fmt(solarTotal)+' kWh','☀️','green')}
    ${kpi('Generator Energy', fmt(genTotal)+' kWh','🔌','amber')}
    ${kpi('Total Energy', fmt(totalEnergy)+' kWh','⚡','blue')}
    ${kpi('Renewable %', renewPct.toFixed(1)+'%','🌱','green')}
    ${kpi('Non-Renewable %', (100-renewPct).toFixed(1)+'%','⚙️','red')}
    ${kpi('Solar Contribution', ((solarTotal/totalEnergy||0)*100).toFixed(1)+'%','☀️','green')}
    ${kpi('Generator Contribution', ((genTotal/totalEnergy||0)*100).toFixed(1)+'%','🔌','amber')}
    ${kpi('CO₂ Reduction (Solar)', fmt(co2Reduction/1000,2)+' tCO₂','🌿','green')}
    ${kpi('Fuel Cost (Diesel)', fmt(dieselTotal*110)+' ৳','💰','amber')}
  </div>
  <div class="charts-grid">
    <div class="card"><h3>Solar vs Generator (Monthly)</h3><div class="chart-box"><canvas id="pr-mix"></canvas></div></div>
    <div class="card"><h3>Solar Monthly Generation</h3><div class="chart-box"><canvas id="pr-perf"></canvas></div></div>
  </div>
  <div class="card">
    <h3>Solar Records <span class="badge badge-green">${solar.length}</span></h3>
    <div class="table-wrap"><table>
      <thead><tr>${solarCols.map(c=>`<th>${c.label}</th>`).join('')}${Auth.can('add')||Auth.can('delete')?'<th class="no-print">Actions</th>':''}</tr></thead>
      <tbody>${solar.map(r=>`<tr>${solarCols.map(c=>`<td>${c.fmt?c.fmt(r[c.key],r):(r[c.key]??'')}</td>`).join('')}${actionCol(r.id,'solar','Solar',editSolar)}</tr>`).join('')}</tbody>
    </table></div>
  </div>
  <div class="card" style="margin-top:14px;">
    <h3>Generator Records <span class="badge badge-amber">${gen.length}</span> ${Auth.can('add')||Auth.can('delete')?'<button class="btn btn-sm btn-primary" id="add-gen">＋ Add Generator</button>':''}</h3>
    <div class="table-wrap"><table>
      <thead><tr>${genCols.map(c=>`<th>${c.label}</th>`).join('')}${Auth.can('add')||Auth.can('delete')?'<th class="no-print">Actions</th>':''}</tr></thead>
      <tbody>${gen.map(r=>`<tr>${genCols.map(c=>`<td>${c.fmt?c.fmt(r[c.key],r):(r[c.key]??'')}</td>`).join('')}${actionCol(r.id,'generator','Generator',editGen)}</tr>`).join('')}</tbody>
    </table></div>
  </div>`;
  wireModuleToolbar('production','solar',solarCols,()=>editSolar());
  $('#add-gen')?.addEventListener('click',()=>editGen());
  makeChart('pr-mix',{ type:'bar', data:{ labels:MONTHS, datasets:[
    {label:'Solar', data:monthlySeries(DB.data.solar,'monthly',y), backgroundColor:'#10b981', stack:'a'},
    {label:'Generator', data:monthlySeries(DB.data.generator,'energy',y), backgroundColor:'#f59e0b', stack:'a'}
  ]}, options:{responsive:true,maintainAspectRatio:false, scales:{x:{stacked:true}, y:{stacked:true}}}});
  makeChart('pr-perf',{ type:'line', data:{ labels:MONTHS, datasets:[
    {label:'Monthly (kWh)', data:monthlySeries(DB.data.solar,'monthly',y), borderColor:'#10b981', backgroundColor:'rgba(16,185,129,.15)', fill:true, tension:.35}
  ]}, options:{responsive:true,maintainAspectRatio:false}});
}
function editSolar(row){
  const r = row||{ month:1,year:CURRENT_YEAR,dailyAvg:0,monthly:0,hours:0 };
  const html = `
    <div class="form-row">
      ${selectField('month','Month',MONTHS,MONTHS[r.month-1])}
      <div class="form-group"><label>Year</label><select name="year">${YEARS.map(y=>`<option ${y===r.year?'selected':''}>${y}</option>`).join('')}</select></div>
    </div>
    <div class="form-row">
      ${inputField('dailyAvg','Daily Generation (kWh)','number',r.dailyAvg)}
      ${inputField('monthly','Monthly Generation (kWh)','number',r.monthly)}
    </div>
    ${inputField('hours','Operating Hours','number',r.hours)}`;
  openModal(html,(obj,close)=>{
    const rec = { id:r.id||uid(), month:MONTHS.indexOf(obj.month)+1, year:+obj.year, dailyAvg:+obj.dailyAvg, monthly:+obj.monthly, hours:+obj.hours };
    if (row){Object.assign(row,rec); DB.audit('Update','Solar','Row '+rec.id);} else {DB.data.solar.push(rec); DB.audit('Create','Solar','Row '+rec.id);}
    DB.save(); close(); toast('Saved'); renderRoute();
  }, row?'Edit Solar':'Add Solar');
}
function editGen(row){
  const r = row||{ month:1,year:CURRENT_YEAR,fuel:'Diesel',hours:0,diesel:0,energy:0,efficiency:3.5,loading:70 };
  const html = `
    <div class="form-row">
      ${selectField('month','Month',MONTHS,MONTHS[r.month-1])}
      <div class="form-group"><label>Year</label><select name="year">${YEARS.map(y=>`<option ${y===r.year?'selected':''}>${y}</option>`).join('')}</select></div>
    </div>
    <div class="form-row">
      ${selectField('fuel','Fuel Type',['Diesel','Natural Gas'], r.fuel||'Diesel')}
      ${inputField('hours','Running Hours','number',r.hours)}
    </div>
    <div class="form-row">
      ${inputField('diesel','Fuel Consumption (L for Diesel / m³ for Natural Gas)','number',r.diesel)}
      ${inputField('energy','Energy Produced (kWh)','number',r.energy)}
    </div>
    <div class="form-row">
      ${inputField('efficiency','Fuel Efficiency (kWh per L or m³)','number',r.efficiency)}
      ${inputField('loading','Generator Loading %','number',r.loading)}
    </div>`;
  openModal(html,(obj,close)=>{
    const rec = { id:r.id||uid(), month:MONTHS.indexOf(obj.month)+1, year:+obj.year, fuel:obj.fuel||'Diesel', hours:+obj.hours, diesel:+obj.diesel, energy:+obj.energy, efficiency:+obj.efficiency, loading:+obj.loading };
    if (row){Object.assign(row,rec); DB.audit('Update','Generator','Row '+rec.id);} else {DB.data.generator.push(rec); DB.audit('Create','Generator','Row '+rec.id);}
    DB.save(); close(); toast('Saved'); renderRoute();
  }, row?'Edit Generator':'Add Generator');
}

/* ============ Module: Waste Management ============ */
function renderModuleWaste(el){
  const rows = filterRows(DB.data.waste, 'waste');
  const y = State.yearFilter==='all'?CURRENT_YEAR:State.yearFilter;
  const yr = yearData(DB.data.waste,y);
  const totalW = sum(yr,'quantity');
  const recycled = sum(yr.filter(r=>r.disposal==='Recycled'),'quantity');
  const landfill = sum(yr.filter(r=>r.disposal==='Landfill'),'quantity');
  const haz = sum(yr.filter(r=>r.hazardous),'quantity');
  const prod = sum(yearData(DB.data.production,y),'quantity');
  const diversion = totalW>0 ? ((totalW-landfill)/totalW*100) : 0;
  const byType = {}; yr.forEach(r=>byType[r.type]=(byType[r.type]||0)+r.quantity);
  const cols = [
    {key:'month',label:'Month',fmt:v=>MONTHS[v-1]},
    {key:'year',label:'Year'},
    {key:'type',label:'Type'},
    {key:'department',label:'Dept'},
    {key:'quantity',label:'Qty',fmt:v=>fmt(v)},
    {key:'unit',label:'Unit'},
    {key:'storage',label:'Storage'},
    {key:'disposal',label:'Disposal',fmt:v=>`<span class="badge ${v==='Recycled'?'badge-green':v==='Landfill'?'badge-red':'badge-amber'}">${v}</span>`},
    {key:'vendor',label:'Vendor'},
    {key:'revenue',label:'Revenue',fmt:v=>fmt(v)},
    {key:'cost',label:'Cost',fmt:v=>fmt(v)},
  ];
  el.innerHTML = `
  ${moduleToolbar('waste')}
  <div class="kpi-grid">
    ${kpi('Total Waste', fmt(totalW)+' kg','🗑️','purple')}
    ${kpi('Recycled Waste', fmt(recycled)+' kg','♻️','green')}
    ${kpi('Landfilled', fmt(landfill)+' kg','🚛','red')}
    ${kpi('Hazardous', fmt(haz)+' kg','☣️','red')}
    ${kpi('Diversion Rate', diversion.toFixed(1)+'%','📈','green')}
    ${kpi('Waste Intensity', prod>0?(totalW/prod).toFixed(4)+' kg/kg':'-','📊','indigo')}
  </div>
  <div class="charts-grid">
    <div class="card"><h3>Waste by Type</h3><div class="chart-box"><canvas id="ws-type"></canvas></div></div>
    <div class="card"><h3>Disposal Method</h3><div class="chart-box"><canvas id="ws-disp"></canvas></div></div>
    <div class="card"><h3>Monthly Waste Trend</h3><div class="chart-box"><canvas id="ws-trend"></canvas></div></div>
  </div>
  <div class="card">
    <h3>Waste Records <span class="badge badge-purple">${rows.length}</span></h3>
    <div class="table-wrap"><table>
      <thead><tr>${cols.map(c=>`<th>${c.label}</th>`).join('')}${Auth.can('add')||Auth.can('delete')?'<th class="no-print">Actions</th>':''}</tr></thead>
      <tbody>${rows.length?rows.map(r=>`<tr>${cols.map(c=>`<td>${c.fmt?c.fmt(r[c.key],r):(r[c.key]??'')}</td>`).join('')}${actionCol(r.id,'waste','Waste',editWaste)}</tr>`).join(''):`<tr><td colspan="${cols.length+1}" class="empty">No records</td></tr>`}</tbody>
    </table></div>
  </div>`;
  wireModuleToolbar('waste','waste',cols,()=>editWaste());
  makeChart('ws-type',{ type:'doughnut', data:{labels:Object.keys(byType), datasets:[{data:Object.values(byType), backgroundColor:CHART_COLORS}]}, options:{responsive:true,maintainAspectRatio:false}});
  const disp = {}; yr.forEach(r=>disp[r.disposal]=(disp[r.disposal]||0)+r.quantity);
  makeChart('ws-disp',{ type:'pie', data:{labels:Object.keys(disp), datasets:[{data:Object.values(disp), backgroundColor:['#10b981','#ef4444','#f59e0b','#0ea5e9','#8b5cf6','#14b8a6']}]}, options:{responsive:true,maintainAspectRatio:false}});
  makeChart('ws-trend',{ type:'bar', data:{labels:MONTHS, datasets:[{label:'kg', data:monthlySeries(DB.data.waste,'quantity',y), backgroundColor:'#8b5cf6'}]}, options:{responsive:true,maintainAspectRatio:false, plugins:{legend:{display:false}}}});
}
function editWaste(row){
  const r = row||{ month:1,year:CURRENT_YEAR,type:WASTE_TYPES[0],department:ENERGY_DEPTS[0],quantity:0,unit:'kg',storage:'Yard-A',disposal:'Recycled',vendor:'',revenue:0,cost:0,remarks:'',hazardous:false };
  const html = `
    <div class="form-row">
      ${selectField('month','Month',MONTHS,MONTHS[r.month-1])}
      <div class="form-group"><label>Year</label><select name="year">${YEARS.map(y=>`<option ${y===r.year?'selected':''}>${y}</option>`).join('')}</select></div>
    </div>
    <div class="form-row">
      ${selectField('type','Waste Type',WASTE_TYPES,r.type)}
      ${selectField('department','Department',ENERGY_DEPTS,r.department)}
    </div>
    <div class="form-row three">
      ${inputField('quantity','Quantity','number',r.quantity)}
      ${selectField('unit','Unit',['kg','tonne','L','m³','pcs'],r.unit)}
      ${inputField('storage','Storage','text',r.storage)}
    </div>
    <div class="form-row">
      ${selectField('disposal','Disposal Method',DISPOSAL_METHODS,r.disposal)}
      ${inputField('vendor','Vendor','text',r.vendor)}
    </div>
    <div class="form-row">
      ${inputField('revenue','Revenue','number',r.revenue)}
      ${inputField('cost','Cost','number',r.cost)}
    </div>
    ${textareaField('remarks','Remarks',r.remarks)}`;
  openModal(html,(obj,close)=>{
    const isHaz = ['Sludge','Chemical Containers','Hazardous Waste','Used Oil','Batteries','E-Waste'].includes(obj.type);
    const rec = { id:r.id||uid(), month:MONTHS.indexOf(obj.month)+1, year:+obj.year, type:obj.type, department:obj.department,
      quantity:+obj.quantity, unit:obj.unit, storage:obj.storage, disposal:obj.disposal, vendor:obj.vendor,
      revenue:+obj.revenue, cost:+obj.cost, remarks:obj.remarks, hazardous:isHaz };
    if (row){Object.assign(row,rec); DB.audit('Update','Waste',rec.type);} else {DB.data.waste.push(rec); DB.audit('Create','Waste',rec.type);}
    DB.save(); close(); toast('Saved'); renderRoute();
  }, row?'Edit Waste':'Add Waste');
}

/* ============ Module: Air Emission ============ */
function renderModuleAir(el){
  const rows = filterRows(DB.data.air, 'air');
  const y = State.yearFilter==='all'?CURRENT_YEAR:State.yearFilter;
  const yr = yearData(DB.data.air, y);
  const byPollutant = {}; AIR_POLLUTANTS.forEach(p=>byPollutant[p]=0);
  yr.forEach(r => { byPollutant[r.pollutant] = (byPollutant[r.pollutant]||0) + (+r.mass||0); });
  const bySource = {}; yr.forEach(r=>{ bySource[r.source] = (bySource[r.source]||0) + (+r.mass||0); });
  const exceedances = yr.filter(r => r.limit>0 && +r.concentration > +r.limit).length;
  const totalMass = Object.values(byPollutant).reduce((a,b)=>a+b,0);

  const cols = [
    {key:'month',label:'Month',fmt:v=>MONTHS[v-1]},
    {key:'year',label:'Year'},
    {key:'source',label:'Source/Stack'},
    {key:'pollutant',label:'Pollutant'},
    {key:'concentration',label:'Conc. (mg/Nm³)',fmt:(v,r)=>{
      const over = r.limit>0 && +v > +r.limit;
      return `<span class="badge ${over?'badge-red':'badge-green'}">${fmt(v)}</span>`;
    }},
    {key:'limit',label:'Limit (mg/Nm³)',fmt:v=>v?fmt(v):'-'},
    {key:'flowRate',label:'Flow (Nm³/h)',fmt:v=>fmt(v)},
    {key:'hours',label:'Op. Hours'},
    {key:'mass',label:'Mass (kg)',fmt:v=>fmt(v,2)},
    {key:'method',label:'Method'},
    {key:'remarks',label:'Remarks'},
  ];

  el.innerHTML = `
  ${moduleToolbar('air')}
  <div class="kpi-grid">
    ${kpi('Total Emission Mass', fmt(totalMass,2)+' kg','🌬️','purple')}
    ${kpi('PM Emitted', fmt(byPollutant['PM (Particulate Matter)']||0,2)+' kg','💨','amber')}
    ${kpi('SO₂ Emitted', fmt(byPollutant['SO₂']||0,2)+' kg','🧪','red')}
    ${kpi('NOx Emitted', fmt(byPollutant['NOx']||0,2)+' kg','☁️','red')}
    ${kpi('CO Emitted', fmt(byPollutant['CO']||0,2)+' kg','🔥','amber')}
    ${kpi('VOC Emitted', fmt(byPollutant['VOC']||0,2)+' kg','🧫','purple')}
    ${kpi('Records', yr.length+'','📊','blue')}
    ${kpi('Limit Exceedances', exceedances+'', exceedances>0?'⚠️':'✅', exceedances>0?'red':'green')}
  </div>
  <div class="charts-grid">
    <div class="card"><h3>Emission by Pollutant</h3><div class="chart-box"><canvas id="air-pol"></canvas></div></div>
    <div class="card"><h3>Emission by Source</h3><div class="chart-box"><canvas id="air-src"></canvas></div></div>
    <div class="card"><h3>Monthly Emission Trend</h3><div class="chart-box"><canvas id="air-trend"></canvas></div></div>
  </div>
  <div class="card">
    <h3>Air Emission Records <span class="badge badge-purple">${rows.length}</span> ${Auth.can('add')||Auth.can('delete')?'<button class="btn btn-sm btn-primary" id="add-air">＋ Add Emission</button>':''}</h3>
    <div class="table-wrap"><table>
      <thead><tr>${cols.map(c=>`<th>${c.label}</th>`).join('')}${Auth.can('add')||Auth.can('delete')?'<th class="no-print">Actions</th>':''}</tr></thead>
      <tbody>${rows.length?rows.map(r=>`<tr>${cols.map(c=>`<td>${c.fmt?c.fmt(r[c.key],r):(r[c.key]??'')}</td>`).join('')}${actionCol(r.id,'air','Air Emission',editAir)}</tr>`).join(''):`<tr><td colspan="${cols.length+1}" class="empty">No records</td></tr>`}</tbody>
    </table></div>
  </div>`;
  wireModuleToolbar('air','air',cols,()=>editAir());
  $('#add-air')?.addEventListener('click',()=>editAir());
  makeChart('air-pol',{ type:'doughnut', data:{ labels:Object.keys(byPollutant), datasets:[{ data:Object.values(byPollutant), backgroundColor:CHART_COLORS }] }, options:{responsive:true,maintainAspectRatio:false}});
  makeChart('air-src',{ type:'pie',      data:{ labels:Object.keys(bySource),    datasets:[{ data:Object.values(bySource),    backgroundColor:CHART_COLORS }] }, options:{responsive:true,maintainAspectRatio:false}});
  makeChart('air-trend',{ type:'bar', data:{ labels:MONTHS, datasets:[{ label:'Mass (kg)', data:monthlySeries(DB.data.air,'mass',y), backgroundColor:'#8b5cf6' }] }, options:{responsive:true,maintainAspectRatio:false, plugins:{legend:{display:false}}}});
}
function editAir(row){
  const defPol = AIR_POLLUTANTS[0];
  const r = row||{ month:1, year:CURRENT_YEAR, source:AIR_SOURCES[0], pollutant:defPol,
    concentration:0, limit:AIR_LIMITS[defPol]||0, flowRate:0, hours:0, mass:0, method:'Isokinetic', remarks:'' };
  const html = `
    <div class="form-row">
      ${selectField('month','Month',MONTHS,MONTHS[r.month-1])}
      <div class="form-group"><label>Year</label><select name="year">${YEARS.map(y=>`<option ${y===r.year?'selected':''}>${y}</option>`).join('')}</select></div>
    </div>
    <div class="form-row">
      ${selectField('source','Source / Stack',AIR_SOURCES,r.source)}
      ${selectField('pollutant','Pollutant',AIR_POLLUTANTS,r.pollutant)}
    </div>
    <div class="form-row">
      ${inputField('concentration','Concentration (mg/Nm³)','number',r.concentration)}
      ${inputField('limit','Regulatory Limit (mg/Nm³)','number',r.limit)}
    </div>
    <div class="form-row">
      ${inputField('flowRate','Stack Flow Rate (Nm³/h)','number',r.flowRate)}
      ${inputField('hours','Operating Hours','number',r.hours)}
    </div>
    <div class="form-row">
      ${inputField('mass','Mass Emitted (kg)','number',r.mass)}
      ${selectField('method','Measurement Method',['Isokinetic','CEMS','Grab Sample','Calculated'],r.method)}
    </div>
    ${textareaField('remarks','Remarks',r.remarks)}
    <p style="color:var(--text-3); font-size:12px; margin-top:6px;">Tip: If Mass is left as 0, it is auto-computed as Concentration × Flow × Hours ÷ 10⁶.</p>`;
  openModal(html,(obj,close)=>{
    const conc = +obj.concentration||0;
    const flow = +obj.flowRate||0;
    const hrs  = +obj.hours||0;
    let mass = +obj.mass;
    if (!mass || mass===0) mass = +(conc * flow * hrs / 1e6).toFixed(3); // mg → kg
    const rec = { id:r.id||uid(), month:MONTHS.indexOf(obj.month)+1, year:+obj.year,
      source:obj.source, pollutant:obj.pollutant,
      concentration:conc, limit:+obj.limit||0, flowRate:flow, hours:hrs,
      mass:mass, method:obj.method, remarks:obj.remarks };
    if (row){Object.assign(row,rec); DB.audit('Update','Air Emission', rec.pollutant+' @ '+rec.source);}
    else {DB.data.air.push(rec); DB.audit('Create','Air Emission', rec.pollutant+' @ '+rec.source);}
    DB.save(); close(); toast('Saved'); renderRoute();
  }, row?'Edit Air Emission':'Add Air Emission');
}

/* ============ Module: Production Data ============ */
function renderModuleProductionData(el){
  const rows = filterRows(DB.data.production, 'prodData');
  const y = State.yearFilter==='all'?CURRENT_YEAR:State.yearFilter;
  const t = totals(y);
  const cols = [
    {key:'month',label:'Month',fmt:v=>MONTHS[v-1]},
    {key:'year',label:'Year'},
    {key:'quantity',label:'Production (kg)',fmt:v=>fmt(v)},
    {key:'pieces',label:'Pieces',fmt:v=>fmt(v)},
    {key:'fabricWeight',label:'Fabric Wt. (kg)',fmt:v=>fmt(v)},
    {key:'workingDays',label:'Days'},
  ];
  el.innerHTML = `
  ${moduleToolbar('prodData')}
  <div class="kpi-grid">
    ${kpi('Total Production', fmt(t.totalProduction)+' kg','🏭','blue')}
    ${kpi('Total Pieces', fmt(t.totalPieces),'👕','blue')}
    ${kpi('Energy Intensity', t.energyIntensity.toFixed(3)+' kWh/kg','⚡','indigo')}
    ${kpi('Water Intensity', t.waterIntensity.toFixed(3)+' m³/kg','💧','teal')}
    ${kpi('Gas Intensity', t.gasIntensity.toFixed(4)+' m³/kg','🔥','red')}
    ${kpi('Waste Intensity', t.wasteIntensity.toFixed(4)+' kg/kg','🗑️','purple')}
    ${kpi('WW Intensity', t.wwIntensity.toFixed(3)+' m³/kg','🚿','amber')}
    ${kpi('CO₂ per kg', t.co2PerKg.toFixed(3)+' kg','🌱','green')}
  </div>
  <div class="card">
    <h3>Production Records <span class="badge badge-blue">${rows.length}</span></h3>
    <div class="table-wrap"><table>
      <thead><tr>${cols.map(c=>`<th>${c.label}</th>`).join('')}${Auth.can('add')||Auth.can('delete')?'<th class="no-print">Actions</th>':''}</tr></thead>
      <tbody>${rows.length?rows.map(r=>`<tr>${cols.map(c=>`<td>${c.fmt?c.fmt(r[c.key],r):(r[c.key]??'')}</td>`).join('')}${actionCol(r.id,'production','Production',editProd)}</tr>`).join(''):`<tr><td colspan="${cols.length+1}" class="empty">No records</td></tr>`}</tbody>
    </table></div>
  </div>`;
  wireModuleToolbar('prodData','production',cols,()=>editProd());
}
function editProd(row){
  const r = row||{ month:1,year:CURRENT_YEAR,quantity:0,pieces:0,fabricWeight:0,workingDays:26 };
  const html = `
    <div class="form-row">
      ${selectField('month','Month',MONTHS,MONTHS[r.month-1])}
      <div class="form-group"><label>Year</label><select name="year">${YEARS.map(y=>`<option ${y===r.year?'selected':''}>${y}</option>`).join('')}</select></div>
    </div>
    <div class="form-row">
      ${inputField('quantity','Production (kg)','number',r.quantity)}
      ${inputField('pieces','Pieces','number',r.pieces)}
    </div>
    <div class="form-row">
      ${inputField('fabricWeight','Fabric Weight (kg)','number',r.fabricWeight)}
      ${inputField('workingDays','Working Days','number',r.workingDays)}
    </div>`;
  openModal(html,(obj,close)=>{
    const rec = { id:r.id||uid(), month:MONTHS.indexOf(obj.month)+1, year:+obj.year, quantity:+obj.quantity, pieces:+obj.pieces, fabricWeight:+obj.fabricWeight, workingDays:+obj.workingDays };
    if (row){Object.assign(row,rec); DB.audit('Update','Production','Row '+rec.id);} else {DB.data.production.push(rec); DB.audit('Create','Production','Row '+rec.id);}
    DB.save(); close(); toast('Saved'); renderRoute();
  }, row?'Edit Production':'Add Production');
}

/* ============ Module: Carbon Footprint ============ */
function renderCarbon(){
  const t = totals();
  const ef = DB.data.emissionFactors;
  const gasCO2 = t.gas*ef.natural_gas;
  const dieselCO2 = t.diesel*ef.diesel;
  const elecCO2 = t.electricity*ef.electricity;
  const html = `
  <div class="toolbar no-print">
    <select id="yearSel2">${YEARS.map(y=>`<option ${y===State.yearFilter?'selected':''}>${y}</option>`).join('')}</select>
    <div style="flex:1"></div>
    ${Auth.can('add')||Auth.can('delete')?'<button class="btn btn-primary" id="edit-ef">✏️ Edit Emission Factors</button>':''}
  </div>
  <div class="kpi-grid">
    ${kpi('Scope 1 CO₂', fmt(t.scope1/1000,2)+' tCO₂','🏭','red')}
    ${kpi('Scope 2 CO₂', fmt(t.scope2/1000,2)+' tCO₂','⚡','amber')}
    ${kpi('Total CO₂', fmt(t.carbon/1000,2)+' tCO₂','🌍','red')}
    ${kpi('CO₂ per kg Prod.', t.co2PerKg.toFixed(3)+' kg','📉','indigo')}
    ${kpi('CO₂ per Piece', t.co2PerPc.toFixed(4)+' kg','👕','indigo')}
    ${kpi('Solar CO₂ Avoided', fmt(t.solar*ef.electricity/1000,2)+' tCO₂','🌱','green')}
  </div>
  <div class="charts-grid">
    <div class="card"><h3>Emission Sources</h3><div class="chart-box"><canvas id="cb-src"></canvas></div></div>
    <div class="card"><h3>Monthly CO₂ Emissions</h3><div class="chart-box"><canvas id="cb-mo"></canvas></div></div>
    <div class="card"><h3>Three-Year Emission Trend</h3><div class="chart-box"><canvas id="cb-3yr"></canvas></div></div>
    <div class="card"><h3>Scope Breakdown</h3><div class="chart-box"><canvas id="cb-scope"></canvas></div></div>
  </div>
  <div class="card">
    <h3>Current Emission Factors</h3>
    <div class="table-wrap"><table>
      <thead><tr><th>Source</th><th>Factor</th><th>Unit</th></tr></thead>
      <tbody>
        <tr><td>Natural Gas</td><td>${ef.natural_gas}</td><td>kg CO₂ / m³</td></tr>
        <tr><td>Diesel</td><td>${ef.diesel}</td><td>kg CO₂ / litre</td></tr>
        <tr><td>LPG</td><td>${ef.lpg}</td><td>kg CO₂ / kg</td></tr>
        <tr><td>Purchased Electricity</td><td>${ef.electricity}</td><td>kg CO₂ / kWh</td></tr>
      </tbody>
    </table></div>
  </div>`;
  return html;
}
window._post_carbon = function(){
  const y = State.yearFilter;
  $('#yearSel2')?.addEventListener('change', e=>{ State.yearFilter=+e.target.value; renderRoute(); });
  $('#edit-ef')?.addEventListener('click', ()=>{
    const ef = DB.data.emissionFactors;
    const html = `
      ${inputField('natural_gas','Natural Gas (kg CO₂/m³)','number',ef.natural_gas)}
      ${inputField('diesel','Diesel (kg CO₂/L)','number',ef.diesel)}
      ${inputField('lpg','LPG (kg CO₂/kg)','number',ef.lpg)}
      ${inputField('electricity','Electricity (kg CO₂/kWh)','number',ef.electricity)}`;
    openModal(html,(obj,close)=>{
      DB.data.emissionFactors = { natural_gas:+obj.natural_gas, diesel:+obj.diesel, lpg:+obj.lpg, electricity:+obj.electricity };
      DB.audit('Update','Emission Factors','Modified factors'); DB.save(); close(); toast('Updated'); renderRoute();
    },'Edit Emission Factors');
  });
  const t = totals();
  const ef = DB.data.emissionFactors;
  makeChart('cb-src',{ type:'doughnut', data:{ labels:['Natural Gas','Diesel','Electricity'], datasets:[{data:[t.gas*ef.natural_gas, t.diesel*ef.diesel, t.electricity*ef.electricity], backgroundColor:['#ef4444','#f59e0b','#0ea5e9']}]}, options:{responsive:true,maintainAspectRatio:false}});
  const gasMonth = monthlySeries(DB.data.gas,'consumption',y).map(v=>v*ef.natural_gas);
  const dieselMonth = monthlySeries(DB.data.generator,'diesel',y).map(v=>v*ef.diesel);
  const elecMonth = monthlySeries(DB.data.energy,'consumption',y).map(v=>v*ef.electricity);
  makeChart('cb-mo',{ type:'bar', data:{labels:MONTHS, datasets:[
    {label:'Natural Gas', data:gasMonth, backgroundColor:'#ef4444', stack:'s'},
    {label:'Diesel', data:dieselMonth, backgroundColor:'#f59e0b', stack:'s'},
    {label:'Electricity', data:elecMonth, backgroundColor:'#0ea5e9', stack:'s'}
  ]}, options:{responsive:true,maintainAspectRatio:false, scales:{x:{stacked:true}, y:{stacked:true}}}});
  makeChart('cb-3yr',{ type:'line', data:{labels:MONTHS, datasets:YEARS.map((yy,i)=>({
    label:yy,
    data: monthlySeries(DB.data.gas,'consumption',yy).map((v,i)=>v*ef.natural_gas + monthlySeries(DB.data.generator,'diesel',yy)[i]*ef.diesel + monthlySeries(DB.data.energy,'consumption',yy)[i]*ef.electricity),
    borderColor:CHART_COLORS[i], tension:.35
  }))}, options:{responsive:true,maintainAspectRatio:false}});
  makeChart('cb-scope',{ type:'pie', data:{labels:['Scope 1','Scope 2'], datasets:[{data:[t.scope1,t.scope2], backgroundColor:['#ef4444','#f59e0b']}]}, options:{responsive:true,maintainAspectRatio:false}});
};

/* ============ 3-Year Comparison ============ */
function renderCompare3(){
  // Determine three years to compare: prefer the three most-recent years that have any data;
  // fall back to CURRENT_YEAR-2..CURRENT_YEAR.
  const allYears = new Set();
  ['energy','water','wastewater','recycle','gas','solar','generator','waste','production','steam','air'].forEach(k=>{
    (DB.data[k]||[]).forEach(r=>{ if (r && r.year) allYears.add(+r.year); });
  });
  let yrs = Array.from(allYears).sort((a,b)=>b-a).slice(0,3).sort((a,b)=>a-b);
  if (yrs.length < 3) {
    yrs = [CURRENT_YEAR-2, CURRENT_YEAR-1, CURRENT_YEAR];
  }
  const [yA, yB, yC] = yrs;
  const tA = totals(yA), tB = totals(yB), tC = totals(yC);

  const pct = (curr, prev) => {
    if (!prev) return prev===0 && curr===0 ? '—' : (curr>0?'+∞':'—');
    const p = ((curr-prev)/prev)*100;
    const sign = p>=0?'+':'';
    const cls = p>=0?'badge-red':'badge-green';
    return `<span class="badge ${cls}">${sign}${p.toFixed(1)}%</span>`;
  };
  const pctGood = (curr, prev) => { // higher is better (renewable %, recycling)
    if (!prev) return '—';
    const p = ((curr-prev)/prev)*100;
    const sign = p>=0?'+':'';
    const cls = p>=0?'badge-green':'badge-red';
    return `<span class="badge ${cls}">${sign}${p.toFixed(1)}%</span>`;
  };

  const rows = [
    { grp:'Consumption', label:'Electricity',        unit:'kWh',    a:tA.electricity,    b:tB.electricity,    c:tC.electricity,    good:'low' },
    { grp:'Consumption', label:'Water',              unit:'m³',     a:tA.water,          b:tB.water,          c:tC.water,          good:'low' },
    { grp:'Consumption', label:'Natural Gas',        unit:'m³',     a:tA.gas,            b:tB.gas,            c:tC.gas,            good:'low' },
    { grp:'Consumption', label:'Diesel',             unit:'L',      a:tA.diesel,         b:tB.diesel,         c:tC.diesel,         good:'low' },
    { grp:'Consumption', label:'Steam Consumed',     unit:'MT',     a:tA.steamCons,      b:tB.steamCons,      c:tC.steamCons,      good:'low' },
    { grp:'Consumption', label:'Wastewater (Effluent)', unit:'m³',  a:tA.wastewater,     b:tB.wastewater,     c:tC.wastewater,     good:'low' },
    { grp:'Consumption', label:'Total Energy',       unit:'kWh',    a:tA.totalEnergy,    b:tB.totalEnergy,    c:tC.totalEnergy,    good:'low' },
    { grp:'Production',  label:'Production Qty',    unit:'kg',      a:tA.totalProduction,b:tB.totalProduction,c:tC.totalProduction,good:'high'},
    { grp:'Production',  label:'Pieces Produced',   unit:'pcs',     a:tA.totalPieces,    b:tB.totalPieces,    c:tC.totalPieces,    good:'high'},
    { grp:'Production',  label:'Solar Generated',   unit:'kWh',     a:tA.solar,          b:tB.solar,          c:tC.solar,          good:'high'},
    { grp:'Production',  label:'Steam Generated',   unit:'MT',      a:tA.steamGen,       b:tB.steamGen,       c:tC.steamGen,       good:'high'},
    { grp:'Production',  label:'Generator Energy',  unit:'kWh',     a:tA.genEnergy,      b:tB.genEnergy,      c:tC.genEnergy,      good:'low' },
    { grp:'Sustainability', label:'Renewable %',    unit:'%',       a:tA.renewablePct,   b:tB.renewablePct,   c:tC.renewablePct,   good:'high', dp:1 },
    { grp:'Sustainability', label:'Water Recycle %', unit:'%',      a:tA.recycleRate,    b:tB.recycleRate,    c:tC.recycleRate,    good:'high', dp:1 },
    { grp:'Sustainability', label:'Total Waste',     unit:'kg',     a:tA.totalWaste,     b:tB.totalWaste,     c:tC.totalWaste,     good:'low' },
    { grp:'Sustainability', label:'CO₂ Emissions',   unit:'kg',     a:tA.carbon,         b:tB.carbon,         c:tC.carbon,         good:'low' },
    { grp:'Air Emission',   label:'Total Air Emissions', unit:'kg', a:tA.airTotal,       b:tB.airTotal,       c:tC.airTotal,       good:'low', dp:2 },
    { grp:'Air Emission',   label:'PM',              unit:'kg',     a:tA.airPM,          b:tB.airPM,          c:tC.airPM,          good:'low', dp:2 },
    { grp:'Air Emission',   label:'SO₂',             unit:'kg',     a:tA.airSO2,         b:tB.airSO2,         c:tC.airSO2,         good:'low', dp:2 },
    { grp:'Air Emission',   label:'NOx',             unit:'kg',     a:tA.airNOx,         b:tB.airNOx,         c:tC.airNOx,         good:'low', dp:2 },
    { grp:'Air Emission',   label:'CO',              unit:'kg',     a:tA.airCO,          b:tB.airCO,          c:tC.airCO,          good:'low', dp:2 },
    { grp:'Air Emission',   label:'VOC',             unit:'kg',     a:tA.airVOC,         b:tB.airVOC,         c:tC.airVOC,         good:'low', dp:2 },
    { grp:'Air Emission',   label:'Limit Exceedances', unit:'',     a:tA.airExceedances, b:tB.airExceedances, c:tC.airExceedances, good:'low' },
    { grp:'Intensity',    label:'Energy Intensity',  unit:'kWh/kg', a:tA.energyIntensity,b:tB.energyIntensity,c:tC.energyIntensity, good:'low', dp:3 },
    { grp:'Intensity',    label:'Water Intensity',   unit:'m³/kg',  a:tA.waterIntensity, b:tB.waterIntensity, c:tC.waterIntensity,  good:'low', dp:3 },
    { grp:'Intensity',    label:'CO₂ per kg',        unit:'kg/kg',  a:tA.co2PerKg,       b:tB.co2PerKg,       c:tC.co2PerKg,        good:'low', dp:3 },
  ];

  const fmtVal = (v, dp) => (v==null||isNaN(v))?'0':Number(v).toLocaleString('en-US',{minimumFractionDigits:dp||0, maximumFractionDigits:dp||0});

  const groups = ['Consumption','Production','Sustainability','Air Emission','Intensity'];
  const tableHtml = groups.map(g => {
    const grpRows = rows.filter(r=>r.grp===g);
    return `
      <tr class="grp-row"><td colspan="7" style="font-weight:600; background:var(--surface-2, #f1f5f9);">${g}</td></tr>
      ${grpRows.map(r=>{
        const dp = r.dp||0;
        const pctFn = r.good==='high'?pctGood:pct;
        return `<tr>
          <td>${r.label}</td>
          <td style="text-align:right;">${fmtVal(r.a,dp)} ${r.unit}</td>
          <td style="text-align:right;">${fmtVal(r.b,dp)} ${r.unit}</td>
          <td style="text-align:right;">${fmtVal(r.c,dp)} ${r.unit}</td>
          <td style="text-align:center;">${pctFn(r.b,r.a)}</td>
          <td style="text-align:center;">${pctFn(r.c,r.b)}</td>
          <td style="text-align:center;">${pctFn(r.c,r.a)}</td>
        </tr>`;
      }).join('')}
    `;
  }).join('');

  return `
  <div class="page-header">
    <h2>3-Year Comparison — ${yA} vs ${yB} vs ${yC}</h2>
    <p style="color:var(--text-3);">Consumption, production, sustainability and intensity metrics compared across three years.</p>
  </div>

  <div class="kpi-grid">
    ${kpi('Electricity Trend', ((tC.electricity - tA.electricity)/(tA.electricity||1)*100).toFixed(1)+'%', '⚡', 'blue')}
    ${kpi('Water Trend',       ((tC.water       - tA.water)/(tA.water||1)*100).toFixed(1)+'%', '💧', 'teal')}
    ${kpi('Gas Trend',         ((tC.gas         - tA.gas)/(tA.gas||1)*100).toFixed(1)+'%', '🔥', 'red')}
    ${kpi('Production Trend',  ((tC.totalProduction - tA.totalProduction)/(tA.totalProduction||1)*100).toFixed(1)+'%', '🏭', 'amber')}
    ${kpi('Renewable Trend',   (tC.renewablePct - tA.renewablePct).toFixed(1)+' pp', '🌱', 'green')}
    ${kpi('CO₂ Trend',         ((tC.carbon      - tA.carbon)/(tA.carbon||1)*100).toFixed(1)+'%', '🌍', 'purple')}
    ${kpi('Air Emission Trend',((tC.airTotal    - tA.airTotal)/(tA.airTotal||1)*100).toFixed(1)+'%', '🌬️', 'purple')}
  </div>

  <div class="charts-grid">
    <div class="card"><h3>Electricity (Monthly)</h3><div class="chart-box"><canvas id="c3-elec"></canvas></div></div>
    <div class="card"><h3>Water (Monthly)</h3><div class="chart-box"><canvas id="c3-water"></canvas></div></div>
    <div class="card"><h3>Natural Gas (Monthly)</h3><div class="chart-box"><canvas id="c3-gas"></canvas></div></div>
    <div class="card"><h3>Production Qty (Monthly)</h3><div class="chart-box"><canvas id="c3-prod"></canvas></div></div>
    <div class="card"><h3>Solar Generation (Monthly)</h3><div class="chart-box"><canvas id="c3-solar"></canvas></div></div>
    <div class="card"><h3>CO₂ Emissions Estimate (Annual)</h3><div class="chart-box"><canvas id="c3-co2"></canvas></div></div>
    <div class="card"><h3>Air Emissions (Monthly)</h3><div class="chart-box"><canvas id="c3-air"></canvas></div></div>
    <div class="card"><h3>Air Emissions by Pollutant (Annual)</h3><div class="chart-box"><canvas id="c3-air-pol"></canvas></div></div>
  </div>

  <div class="card" style="margin-top:14px;">
    <h3>Detailed Metrics — ${yA}, ${yB}, ${yC}</h3>
    <div class="table-wrap"><table>
      <thead><tr>
        <th>Metric</th>
        <th style="text-align:right;">${yA}</th>
        <th style="text-align:right;">${yB}</th>
        <th style="text-align:right;">${yC}</th>
        <th style="text-align:center;">${yB} vs ${yA}</th>
        <th style="text-align:center;">${yC} vs ${yB}</th>
        <th style="text-align:center;">${yC} vs ${yA}</th>
      </tr></thead>
      <tbody>${tableHtml}</tbody>
    </table></div>
  </div>
  <div style="margin-top:8px; color:var(--text-3); font-size:12px;">Note: For consumption, waste and emissions, red = increase (worse). For production and renewable/recycle rates, green = increase (better).</div>
  `;
}
window._post_compare3 = function(){
  // Same year detection as the render
  const allYears = new Set();
  ['energy','water','wastewater','recycle','gas','solar','generator','waste','production','steam','air'].forEach(k=>{
    (DB.data[k]||[]).forEach(r=>{ if (r && r.year) allYears.add(+r.year); });
  });
  let yrs = Array.from(allYears).sort((a,b)=>b-a).slice(0,3).sort((a,b)=>a-b);
  if (yrs.length < 3) yrs = [CURRENT_YEAR-2, CURRENT_YEAR-1, CURRENT_YEAR];
  const [yA, yB, yC] = yrs;
  const colors = ['#94a3b8','#0ea5e9','#10b981'];

  const build = (arr, key) => ({
    type:'line',
    data:{ labels:MONTHS, datasets:[
      { label:yA, data:monthlySeries(arr,key,yA), borderColor:colors[0], backgroundColor:'rgba(148,163,184,.15)', tension:.35 },
      { label:yB, data:monthlySeries(arr,key,yB), borderColor:colors[1], backgroundColor:'rgba(14,165,233,.15)',  tension:.35 },
      { label:yC, data:monthlySeries(arr,key,yC), borderColor:colors[2], backgroundColor:'rgba(16,185,129,.15)',  tension:.35 },
    ]},
    options:{ responsive:true, maintainAspectRatio:false }
  });
  makeChart('c3-elec',  build(DB.data.energy,     'consumption'));
  makeChart('c3-water', build(DB.data.water,      'consumption'));
  makeChart('c3-gas',   build(DB.data.gas,        'consumption'));
  makeChart('c3-prod',  build(DB.data.production, 'quantity'));
  makeChart('c3-solar', build(DB.data.solar,      'monthly'));

  const tA = totals(yA), tB = totals(yB), tC = totals(yC);
  makeChart('c3-co2', {
    type:'bar',
    data:{ labels:[yA,yB,yC], datasets:[
      { label:'Scope 1', data:[tA.scope1,tB.scope1,tC.scope1], backgroundColor:'#ef4444' },
      { label:'Scope 2', data:[tA.scope2,tB.scope2,tC.scope2], backgroundColor:'#f59e0b' }
    ]},
    options:{ responsive:true, maintainAspectRatio:false, scales:{ x:{stacked:true}, y:{stacked:true} } }
  });

  // Air emissions — monthly line comparison across 3 years
  makeChart('c3-air', build(DB.data.air||[], 'mass'));

  // Air emissions by pollutant — grouped bar for 3 years
  const polLabels = ['PM','SO₂','NOx','CO','VOC','CO₂'];
  const polKeys = ['airPM','airSO2','airNOx','airCO','airVOC','airCO2'];
  makeChart('c3-air-pol', {
    type:'bar',
    data:{ labels:polLabels, datasets:[
      { label:yA, data:polKeys.map(k=>tA[k]), backgroundColor:colors[0] },
      { label:yB, data:polKeys.map(k=>tB[k]), backgroundColor:colors[1] },
      { label:yC, data:polKeys.map(k=>tC[k]), backgroundColor:colors[2] }
    ]},
    options:{ responsive:true, maintainAspectRatio:false }
  });
};

/* ============ Reports ============ */
function renderReports(){
  const reports = [
    { id:'monthly',    ico:'📅', title:'Monthly Utility Report',    desc:'Complete monthly utility overview' },
    { id:'energy',     ico:'⚡', title:'Department Energy Report', desc:'Consumption per department' },
    { id:'water',      ico:'💧', title:'Water Consumption Report', desc:'Source and area breakdown' },
    { id:'ww',         ico:'🚿', title:'Wastewater Report',        desc:'Influent, effluent, efficiency' },
    { id:'recycle',    ico:'♻️', title:'Water Recycling Report',   desc:'Recycling volume and rate' },
    { id:'gas',        ico:'🔥', title:'Natural Gas Report',       desc:'Gas usage by department' },
    { id:'waste',      ico:'🗑️', title:'Waste Report',              desc:'Type, disposal, revenue' },
    { id:'air',        ico:'🌬️', title:'Air Emission Report',       desc:'Stack pollutants, mass, exceedances' },
    { id:'solar',      ico:'☀️', title:'Solar Performance Report', desc:'Solar generation metrics' },
    { id:'gen',        ico:'🔌', title:'Generator Report',          desc:'Runtime, fuel, energy' },
    { id:'carbon',     ico:'🌱', title:'Carbon Footprint Report',   desc:'Scope 1 & 2 emissions' },
    { id:'kpi',        ico:'📊', title:'Environmental KPI Report',  desc:'All intensities & percentages' },
    { id:'exec',       ico:'📑', title:'Executive Dashboard',       desc:'Top-line summary for management' },
    { id:'3yr',        ico:'📈', title:'Three-Year Comparison',     desc:'YoY performance analysis' },
  ];
  return `
  <div class="section-title">Available Reports<span style="font-size:12px; color:var(--text-3); font-weight:normal;">Click a report to export</span></div>
  <div class="report-grid">
    ${reports.map(r=>`<div class="report-card" data-report="${r.id}"><div class="r-ico">${r.ico}</div><h4>${r.title}</h4><p>${r.desc}</p></div>`).join('')}
  </div>`;
}
window._post_reports = function(){
  $$('.report-card').forEach(c=>c.addEventListener('click', ()=>generateReport(c.dataset.report)));
};

function generateReport(id){
  const { jsPDF } = window.jspdf;
  const doc = new jsPDF({ orientation:'landscape' });
  const t = totals();
  const y = State.yearFilter==='all'?CURRENT_YEAR:State.yearFilter;
  doc.setFontSize(16); doc.text('Utility360 — ' + id.toUpperCase() + ' Report', 14, 15);
  doc.setFontSize(10); doc.text(`${DB.data.settings.companyName} • ${y} • Generated ${new Date().toLocaleString()}`, 14, 22);
  let Y = 28;
  const table = (head, body) => { doc.autoTable({ head:[head], body, startY:Y, styles:{fontSize:8}, headStyles:{fillColor:[14,165,233]} }); Y = doc.lastAutoTable.finalY + 6; };

  if (id==='monthly' || id==='exec' || id==='kpi'){
    table(['KPI','Value'], [
      ['Total Electricity (kWh)', fmt(t.electricity)],
      ['Total Water (m³)', fmt(t.water)],
      ['Total Wastewater (m³)', fmt(t.wastewater)],
      ['Recycled Water (m³)', fmt(t.recycled)],
      ['Recycling Rate (%)', t.recycleRate.toFixed(1)],
      ['Natural Gas (m³)', fmt(t.gas)],
      ['Solar Energy (kWh)', fmt(t.solar)],
      ['Renewable %', t.renewablePct.toFixed(1)],
      ['Total Waste (kg)', fmt(t.totalWaste)],
      ['Hazardous Waste (kg)', fmt(t.hazardousWaste)],
      ['Scope 1 CO₂ (t)', (t.scope1/1000).toFixed(2)],
      ['Scope 2 CO₂ (t)', (t.scope2/1000).toFixed(2)],
      ['Air Emissions Total (kg)', fmt(t.airTotal,2)],
      ['PM (kg)', fmt(t.airPM,2)],
      ['SO₂ (kg)', fmt(t.airSO2,2)],
      ['NOx (kg)', fmt(t.airNOx,2)],
      ['Air Emission Exceedances', t.airExceedances],
      ['Energy Intensity (kWh/kg)', t.energyIntensity.toFixed(3)],
      ['Water Intensity (m³/kg)', t.waterIntensity.toFixed(3)],
    ]);
  }
  if (id==='energy'){
    const dept={}; yearData(DB.data.energy,y).forEach(r=>dept[r.department]=(dept[r.department]||0)+r.consumption);
    table(['Department','Consumption (kWh)','% Share'], Object.entries(dept).sort((a,b)=>b[1]-a[1]).map(([k,v])=>[k, fmt(v), ((v/(t.electricity||1))*100).toFixed(1)+'%']));
  }
  if (id==='water'){
    const src={}; yearData(DB.data.water,y).forEach(r=>src[r.source]=(src[r.source]||0)+r.consumption);
    table(['Source','Consumption (m³)','% Share'], Object.entries(src).map(([k,v])=>[k, fmt(v), ((v/(t.water||1))*100).toFixed(1)+'%']));
  }
  if (id==='ww'){
    const type={}; yearData(DB.data.wastewater,y).forEach(r=>{ const k=r.department||r.type||'—'; type[k]=type[k]||{i:0,e:0}; type[k].i+=r.influent; type[k].e+=r.effluent; });
    table(['Department','Influent','Effluent','Efficiency %'], Object.entries(type).map(([k,v])=>[k, fmt(v.i), fmt(v.e), ((v.i-v.e)/(v.i||1)*100).toFixed(1)]));
  }
  if (id==='recycle'){
    const type={}; yearData(DB.data.recycle,y).forEach(r=>type[r.type]=(type[r.type]||0)+r.quantity);
    table(['Type','Quantity (m³)'], Object.entries(type).map(([k,v])=>[k, fmt(v)]));
  }
  if (id==='gas'){
    const dept={}; yearData(DB.data.gas,y).forEach(r=>dept[r.department]=(dept[r.department]||0)+r.consumption);
    table(['Department','Gas (m³)','% Share'], Object.entries(dept).map(([k,v])=>[k, fmt(v), ((v/(t.gas||1))*100).toFixed(1)+'%']));
  }
  if (id==='waste'){
    const type={}; yearData(DB.data.waste,y).forEach(r=>type[r.type]=(type[r.type]||0)+r.quantity);
    table(['Type','Qty (kg)'], Object.entries(type).sort((a,b)=>b[1]-a[1]).map(([k,v])=>[k, fmt(v)]));
  }
  if (id==='air'){
    // Summary by pollutant
    table(['Pollutant','Total Mass (kg)'], [
      ['PM (Particulate Matter)', fmt(t.airPM,2)],
      ['SO₂', fmt(t.airSO2,2)],
      ['NOx', fmt(t.airNOx,2)],
      ['CO',  fmt(t.airCO,2)],
      ['VOC', fmt(t.airVOC,2)],
      ['CO₂', fmt(t.airCO2,2)],
      ['TOTAL', fmt(t.airTotal,2)],
      ['Limit Exceedances', String(t.airExceedances)],
    ]);
    // Detailed records
    const airRows = yearData(DB.data.air||[], y).sort((a,b)=>(a.month-b.month) || String(a.source).localeCompare(String(b.source)));
    table(['Month','Source','Pollutant','Conc. (mg/Nm³)','Limit','Flow (Nm³/h)','Hours','Mass (kg)','Method','Status'],
      airRows.map(r=>[
        MONTHS[r.month-1], r.source, r.pollutant,
        fmt(r.concentration), r.limit?fmt(r.limit):'-',
        fmt(r.flowRate), r.hours, fmt(r.mass,2), r.method||'-',
        (r.limit>0 && +r.concentration > +r.limit) ? 'EXCEED' : 'OK'
      ]));
  }
  if (id==='solar'){
    table(['Month','Daily Avg (kWh)','Monthly (kWh)','Op. Hours'], yearData(DB.data.solar,y).sort((a,b)=>a.month-b.month).map(r=>[MONTHS[r.month-1], fmt(r.dailyAvg), fmt(r.monthly), r.hours]));
  }
  if (id==='gen'){
    table(['Month','Hours','Diesel (L)','Energy (kWh)','Efficiency'], yearData(DB.data.generator,y).sort((a,b)=>a.month-b.month).map(r=>[MONTHS[r.month-1], r.hours, fmt(r.diesel), fmt(r.energy), r.efficiency]));
  }
  if (id==='carbon'){
    table(['Source','Emission (kg CO₂)'], [
      ['Natural Gas', fmt(t.gas*DB.data.emissionFactors.natural_gas)],
      ['Diesel', fmt(t.diesel*DB.data.emissionFactors.diesel)],
      ['Electricity', fmt(t.electricity*DB.data.emissionFactors.electricity)],
      ['Scope 1 Total', fmt(t.scope1)],
      ['Scope 2 Total', fmt(t.scope2)],
      ['GRAND TOTAL', fmt(t.carbon)],
    ]);
  }
  if (id==='3yr'){
    table(['Year','Electricity','Water','Gas','Waste','CO₂ (t)','Air Emissions (kg)','Air Exceedances'], YEARS.map(yy=>{
      const tt = totals(yy);
      return [yy, fmt(tt.electricity), fmt(tt.water), fmt(tt.gas), fmt(tt.totalWaste), (tt.carbon/1000).toFixed(1), fmt(tt.airTotal,2), tt.airExceedances];
    }));
  }
  doc.save('utility360-report-'+id+'-'+Date.now()+'.pdf');
  DB.audit('Generate Report', id, 'PDF export'); DB.save();
  toast('Report generated');
}

/* ============ Alerts ============ */
function renderAlerts(){
  const t = totals();
  const s = DB.data.settings;
  const list = [];
  if (t.electricity > s.targetElectricity*12) list.push({type:'danger',title:'High Electricity Consumption', msg:`Annual usage ${fmt(t.electricity)} kWh exceeds target of ${fmt(s.targetElectricity*12)}.`});
  if (t.water > s.targetWater*12) list.push({type:'danger',title:'High Water Consumption', msg:`Annual usage ${fmt(t.water)} m³ exceeds target.`});
  if (t.gas > 100000) list.push({type:'warning',title:'High Natural Gas Usage', msg:`Gas consumption ${fmt(t.gas)} m³ this year.`});
  if (t.totalWaste > s.targetWaste*12) list.push({type:'warning',title:'High Waste Generation', msg:`Waste ${fmt(t.totalWaste)} kg exceeds target.`});
  if (t.recycleRate < 20) list.push({type:'warning',title:'Low Water Recycling', msg:`Recycling rate is only ${t.recycleRate.toFixed(1)}% (target ≥ 20%).`});
  // Solar low
  const y = State.yearFilter==='all'?CURRENT_YEAR:State.yearFilter;
  const lastMonth = new Date().getMonth();
  const solarThis = yearData(DB.data.solar,y).find(r=>r.month===lastMonth+1);
  if (solarThis && solarThis.monthly < 4500) list.push({type:'warning',title:'Low Solar Production', msg:`Latest solar generation ${fmt(solarThis.monthly)} kWh below expected.`});
  // Generator hours
  const genHours = sum(yearData(DB.data.generator,y),'hours');
  if (genHours > 1500) list.push({type:'danger',title:'Excess Generator Running Hours', msg:`Generator ran ${genHours} hrs this year — review grid reliability.`});
  // Missing data
  for (let m=1; m<=lastMonth; m++) {
    if (!yearData(DB.data.energy,y).some(r=>r.month===m)) list.push({type:'info',title:'Missing Monthly Data', msg:`No energy records for ${MONTHS[m-1]} ${y}.`});
  }
  // Target exceeded
  const currMonth = new Date().getMonth();
  const thisMonthElec = yearData(DB.data.energy,y).filter(r=>r.month===currMonth+1);
  const mo = sum(thisMonthElec,'consumption');
  if (mo > s.targetElectricity) list.push({type:'danger',title:'Target Exceeded (This Month)', msg:`Current month electricity ${fmt(mo)} kWh > target ${fmt(s.targetElectricity)}.`});

  if (list.length===0) list.push({type:'success', title:'All Systems Normal', msg:'No alerts. All KPIs within target thresholds.'});

  return `
  <div class="section-title">Alerts & Notifications <span class="badge badge-red">${list.filter(x=>x.type==='danger').length} critical</span></div>
  ${list.map(a=>`
    <div class="alert ${a.type}">
      <div class="alert-icon">${a.type==='danger'?'🚨':a.type==='warning'?'⚠️':a.type==='success'?'✅':'ℹ️'}</div>
      <div class="alert-body"><b>${a.title}</b>${a.msg}</div>
    </div>`).join('')}`;
}

/* ============ Audit Trail ============ */
function renderAudit(){
  const items = DB.data.audit.slice(0,200);
  return `
  <div class="toolbar no-print">
    <input class="search" id="au-q" placeholder="Search audit trail..."/>
    <div style="flex:1"></div>
    ${Auth.can('manage_settings')?'<button class="btn btn-danger" id="au-clear">🗑️ Clear Trail</button>':''}
  </div>
  <div id="au-list">${items.length? items.map(a=>`
    <div class="audit-item">
      <b>${a.action}</b> — <span class="badge badge-blue">${a.module}</span> ${a.details||''}
      <small>${new Date(a.timestamp).toLocaleString()} • by <b>${a.user}</b> (${a.role})</small>
    </div>`).join('') : '<div class="empty"><div class="em-ico">🕓</div>No audit records yet.</div>' }</div>`;
}
window._post_audit = function(){
  $('#au-q')?.addEventListener('input', e=>{
    const q = e.target.value.toLowerCase();
    $$('.audit-item').forEach(el=>{ el.style.display = el.textContent.toLowerCase().includes(q)?'':'none'; });
  });
  $('#au-clear')?.addEventListener('click', ()=>{
    if (!confirmDlg('Clear all audit records?')) return;
    DB.data.audit = []; DB.save(); toast('Cleared','warning'); renderRoute();
  });
};

/* ============ Settings ============ */
function renderSettings(){
  const s = DB.data.settings;
  const backups = DB.data.backups.slice(0,10);
  const canManage = Auth.can('manage_settings');
  const canTargets = Auth.can('set_targets') || canManage;
  const customTargets = s.customTargets || [];
  return `
  <div class="charts-grid">
    <div class="card">
      <h3>Company Settings</h3>
      <form id="settings-company-form">
        <div class="form-group"><label>Company Name</label><input name="companyName" value="${s.companyName}" ${!canManage?'readonly':''}/></div>
        ${canManage?'<button class="btn btn-primary" type="submit">💾 Save Company Name</button>':'<small style="color:var(--text-3);">Only Administrators can change company name.</small>'}
      </form>
    </div>

    <div class="card">
      <h3>Sustainability Targets ${canTargets?'':'<small style="color:var(--text-3);">(view only)</small>'}</h3>
      <form id="settings-targets-form">
        <div class="form-row">
          <div class="form-group"><label>Electricity Target (kWh/mo)</label><input name="targetElectricity" type="number" value="${s.targetElectricity}" ${!canTargets?'readonly':''}/></div>
          <div class="form-group"><label>Water Target (m³/mo)</label><input name="targetWater" type="number" value="${s.targetWater}" ${!canTargets?'readonly':''}/></div>
        </div>
        <div class="form-row">
          <div class="form-group"><label>Natural Gas Target (m³/mo)</label><input name="targetGas" type="number" value="${s.targetGas}" ${!canTargets?'readonly':''}/></div>
          <div class="form-group"><label>Steam Target (kg/mo)</label><input name="targetSteam" type="number" value="${s.targetSteam}" ${!canTargets?'readonly':''}/></div>
        </div>
        <div class="form-row">
          <div class="form-group"><label>Wastewater Target (m³/mo)</label><input name="targetWastewater" type="number" value="${s.targetWastewater}" ${!canTargets?'readonly':''}/></div>
          <div class="form-group"><label>Waste Target (kg/mo)</label><input name="targetWaste" type="number" value="${s.targetWaste}" ${!canTargets?'readonly':''}/></div>
        </div>
        <div class="form-row">
          <div class="form-group"><label>CO₂ Target (tCO₂/mo)</label><input name="targetCO2" type="number" value="${s.targetCO2}" ${!canTargets?'readonly':''}/></div>
          <div class="form-group"><label>Renewable Share Target (%)</label><input name="targetRenewable" type="number" value="${s.targetRenewable}" ${!canTargets?'readonly':''}/></div>
        </div>
        <div class="form-group"><label>Water Recycling Rate Target (%)</label><input name="targetRecycle" type="number" value="${s.targetRecycle}" ${!canTargets?'readonly':''}/></div>

        <h4 style="margin-top:14px;">Custom Targets</h4>
        <div id="custom-targets-list">
          ${customTargets.length?customTargets.map((t,idx)=>`
            <div class="form-row" data-idx="${idx}" style="align-items:end;">
              <div class="form-group"><label>Name</label><input class="ct-name" value="${t.name||''}" ${!canTargets?'readonly':''}/></div>
              <div class="form-group"><label>Unit</label><input class="ct-unit" value="${t.unit||''}" ${!canTargets?'readonly':''}/></div>
              <div class="form-group"><label>Value</label><input class="ct-value" type="number" value="${t.value||0}" ${!canTargets?'readonly':''}/></div>
              ${canTargets?`<button type="button" class="btn btn-sm btn-danger ct-del" data-idx="${idx}">🗑️</button>`:''}
            </div>`).join(''):'<small style="color:var(--text-3);">No custom targets yet.</small>'}
        </div>
        ${canTargets?`
          <div style="display:flex; gap:8px; margin-top:10px;">
            <button type="button" class="btn" id="add-custom-target">＋ Add More Targets</button>
            <button type="submit" class="btn btn-primary">💾 Save Targets</button>
          </div>`:''}
      </form>
    </div>

    <div class="card">
      <h3>Data Management</h3>
      <p style="font-size:13px; color:var(--text-2); margin-bottom:12px;">
        Total records: <b>${(DB.data.energy.length+DB.data.water.length+DB.data.wastewater.length+DB.data.recycle.length+DB.data.gas.length+DB.data.solar.length+DB.data.generator.length+DB.data.waste.length+DB.data.production.length+(DB.data.steam?.length||0)+(DB.data.air?.length||0))}</b><br/>
        Storage used: <b>${((JSON.stringify(DB.data).length/1024).toFixed(1))} KB</b>
      </p>
      <div style="display:flex; flex-direction:column; gap:8px;">
        ${Auth.can('export')?'<button class="btn btn-primary" onclick="doBackup()">💾 Download Backup</button>':''}
        ${canManage?'<button class="btn" onclick="doRestore()">📂 Restore from File</button>':''}
        ${canManage?'<button class="btn btn-danger" id="btn-reset">🔄 Reset & Reseed Demo Data</button>':''}
      </div>
      <h3 style="margin-top:16px;">Recent Backups</h3>
      <div class="table-wrap"><table>
        <thead><tr><th>Date</th><th>Size</th></tr></thead>
        <tbody>${backups.map(b=>`<tr><td>${b.date}</td><td>${(b.size/1024).toFixed(1)} KB</td></tr>`).join('') || '<tr><td colspan="2" class="empty">None</td></tr>'}</tbody>
      </table></div>
    </div>

    <div class="card">
      <h3>User Roles & Permissions</h3>
      <div class="table-wrap"><table>
        <thead><tr><th>Role</th><th>Permissions</th></tr></thead>
        <tbody>
          ${Object.entries(ROLES).map(([k,v])=>`<tr><td><span class="badge ${v.color}">${v.label}</span></td><td>${v.perms.join(', ')}</td></tr>`).join('')}
        </tbody>
      </table></div>
      <ul style="font-size:12px; color:var(--text-3); margin-top:10px; line-height:1.7; padding-left:16px;">
        <li><b>Administrator</b>: View all data, export/download, manage users & settings</li>
        <li><b>Compliance Manager</b> / <b>Sustainability Manager</b>: Set sustainability targets</li>
        <li><b>Environment Officer</b> / <b>Utility Manager</b>: Add & delete utility data</li>
      </ul>
    </div>

    <div class="card">
      <h3>About Utility360</h3>
      <p style="font-size:13px; color:var(--text-2); line-height:1.6;">
        <b>Utility360</b> is an enterprise-grade Industrial Utility & Sustainability Management platform for tracking energy, water, gas, steam, waste, and carbon emissions across multi-department facilities.
      </p>
      <ul style="font-size:13px; color:var(--text-2); margin-top:8px; padding-left:18px; line-height:1.8;">
        <li>11 modules with 200+ KPIs (Steam Production included)</li>
        <li>Role-based access control (5 roles)</li>
        <li>PDF, Excel, CSV export</li>
        <li>Signup with role & company name</li>
        <li>Customizable sustainability targets</li>
      </ul>
    </div>
  </div>`;
}
window._post_settings = function(){
  $('#settings-company-form')?.addEventListener('submit', e=>{
    e.preventDefault();
    if (!Auth.can('manage_settings')) { toast('Only Administrators can change company name','error'); return; }
    const fd = new FormData(e.target);
    DB.data.settings.companyName = fd.get('companyName');
    DB.audit('Update','Settings','Company name changed'); DB.save();
    toast('Company name saved'); renderRoute();
  });
  $('#settings-targets-form')?.addEventListener('submit', e=>{
    e.preventDefault();
    if (!Auth.can('set_targets') && !Auth.can('manage_settings')) { toast('Insufficient permissions to set targets','error'); return; }
    const fd = new FormData(e.target);
    DB.data.settings.targetElectricity = +fd.get('targetElectricity');
    DB.data.settings.targetWater = +fd.get('targetWater');
    DB.data.settings.targetGas = +fd.get('targetGas');
    DB.data.settings.targetSteam = +fd.get('targetSteam');
    DB.data.settings.targetWastewater = +fd.get('targetWastewater');
    DB.data.settings.targetWaste = +fd.get('targetWaste');
    DB.data.settings.targetCO2 = +fd.get('targetCO2');
    DB.data.settings.targetRenewable = +fd.get('targetRenewable');
    DB.data.settings.targetRecycle = +fd.get('targetRecycle');
    // Collect custom targets
    const list = $$('#custom-targets-list .form-row');
    DB.data.settings.customTargets = list.map(row=>({
      name: row.querySelector('.ct-name')?.value || '',
      unit: row.querySelector('.ct-unit')?.value || '',
      value: +row.querySelector('.ct-value')?.value || 0
    })).filter(t=>t.name);
    DB.audit('Update','Settings','Targets updated ('+DB.data.settings.customTargets.length+' custom)'); DB.save();
    toast('Targets saved'); renderRoute();
  });
  $('#add-custom-target')?.addEventListener('click', ()=>{
    DB.data.settings.customTargets = DB.data.settings.customTargets || [];
    DB.data.settings.customTargets.push({ name:'New Target', unit:'unit', value:0 });
    DB.save();
    renderRoute();
  });
  $$('.ct-del').forEach(btn=>btn.addEventListener('click', ()=>{
    const idx = +btn.dataset.idx;
    DB.data.settings.customTargets.splice(idx,1);
    DB.save(); renderRoute();
  }));
  $('#btn-reset')?.addEventListener('click', ()=>{
    if (!confirmDlg('Reset all data and reseed demo data? This cannot be undone.')) return;
    DB.reset(); toast('Data reset','warning'); renderRoute();
  });
};

/* ============ Global helpers exposed ============ */
window.doBackup = doBackup;
window.doRestore = doRestore;

})();
